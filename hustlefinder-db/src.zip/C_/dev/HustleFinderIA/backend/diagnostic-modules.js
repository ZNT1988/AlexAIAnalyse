/**
 * 🔍 DIAGNOSTIC EXHAUSTIF DES MODULES ALEX ULTIMATE
 * Analyse complète pour identifier les modules manquants
 */

console.log('🔍 DIAGNOSTIC EXHAUSTIF DES MODULES MANQUANTS');
console.log('='.repeat(60));

try {
  const alexMaster = await import('./systems/AlexMasterSystem.js');
  await alexMaster.default.initialize();
  
  const moduleStatus = alexMaster.default.getModuleStatus();
  console.log('📊 ÉTAT GLOBAL DES MODULES:');
  console.log('- Total enregistrés:', moduleStatus.registry.systemState.totalRegistered);
  console.log('- Total chargés:', moduleStatus.registry.systemState.totalLoaded);
  console.log('- Total échoués:', moduleStatus.registry.systemState.totalFailed);
  console.log('- Ratio d\'activation:', Math.round((moduleStatus.registry.systemState.totalLoaded / moduleStatus.registry.systemState.totalRegistered) * 100) + '%');
  console.log('');
  
  // Analyse détaillée des modules par catégorie
  const categories = moduleStatus.registry.systemState.categories || {};
  console.log('📋 ANALYSE PAR CATÉGORIE:');
  for(const [catName, catData] of Object.entries(categories)) {
    const loaded = catData.loaded || 0;
    const total = catData.total || 0;
    const failed = catData.failed || 0;
    console.log(`- ${catName}: ${loaded}/${total} actifs (${Math.round((loaded/total)*100)}%) - ${failed} échecs`);
  }
  console.log('');
  
  // Liste des modules défaillants
  console.log('❌ MODULES DÉFAILLANTS DÉTECTÉS:');
  const failedModules = moduleStatus.registry.systemState.failedModules || [];
  if (failedModules.length > 0) {
    failedModules.forEach((moduleName, index) => {
      console.log(`${index + 1}. ${moduleName}`);
    });
  } else {
    console.log('Aucun module défaillant répertorié dans le registre');
  }
  console.log('');
  
  // Modules chargés avec succès
  console.log('✅ MODULES ACTIFS:');
  const loadedModules = moduleStatus.registry.systemState.loadedModules || [];
  console.log('Premiers 10 modules actifs:');
  loadedModules.slice(0, 10).forEach((moduleName, index) => {
    console.log(`${index + 1}. ${moduleName}`);
  });
  if (loadedModules.length > 10) {
    console.log(`... et ${loadedModules.length - 10} autres modules actifs`);
  }
  
  console.log('');
  console.log('🎯 OBJECTIF: Passer de', moduleStatus.registry.systemState.totalLoaded, 'à 140+ modules actifs (90%+)');
  
} catch(error) {
  console.log('❌ Erreur diagnostic:', error.message);
  console.log('Stack:', error.stack.split('\n').slice(0,5).join('\n'));
}