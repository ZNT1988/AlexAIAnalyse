/**
 * @fileoverview ClusterManager - Rock-Solid Load Balancing & Scaling
 * Advanced clustering for 99.9% uptime and horizontal scaling
 * 
 * @module ClusterManager
 * @version 1.0.0
 * @author HustleFinder IA Team - Infrastructure Optimization
 */

import cluster from 'cluster';
import os from 'os';
import logger from '../config/logger.js';
import { EventEmitter } from 'events';

/**
 * @class ClusterManager
 * @description Advanced cluster management for production-grade scaling
 */
export class ClusterManager extends EventEmitter {
    constructor(options = {}) {
        super();
        
        this.config = {
            workers: options.workers || os.cpus().length,
            maxWorkers: options.maxWorkers || os.cpus().length * 2,
            minWorkers: options.minWorkers || 2,
            autoScale: options.autoScale !== false,
            gracefulShutdownTimeout: options.gracefulShutdownTimeout || 30000,
            healthCheckInterval: options.healthCheckInterval || 10000,
            restartDelay: options.restartDelay || 1000,
            maxRestarts: options.maxRestarts || 10,
            restartWindow: options.restartWindow || 60000, // 1 minute
            cpuThreshold: options.cpuThreshold || 80, // Auto-scale at 80% CPU
            memoryThreshold: options.memoryThreshold || 80, // Auto-scale at 80% memory
            ...options
        };

        this.workers = new Map();
        this.workerStats = new Map();
        this.metrics = {
            totalRequests: 0,
            totalWorkers: 0,
            restarts: 0,
            uptime: Date.now(),
            avgResponseTime: 0,
            cpuUsage: 0,
            memoryUsage: 0
        };

        this.isShuttingDown = false;
        this.healthCheckTimer = null;
        this.scaleCheckTimer = null;

        if (cluster.isPrimary) {
            this.initializeMaster();
        }
    }

    /**
     * Initialize master process
     */
    initializeMaster() {
        logger.info('🚀 Initializing HustleFinder Cluster Manager');
        logger.info(`📊 CPU Cores: ${os.cpus().length}, Workers: ${this.config.workers}`);

        // Fork initial workers
        this.forkWorkers(this.config.workers);

        // Setup cluster event handlers
        this.setupClusterEvents();

        // Start health monitoring
        this.startHealthMonitoring();

        // Start auto-scaling if enabled
        if (this.config.autoScale) {
            this.startAutoScaling();
        }

        // Setup graceful shutdown handlers
        this.setupGracefulShutdown();

        logger.info('✅ Cluster Manager initialized successfully');
        this.emit('masterReady', {
            workers: this.config.workers,
            autoScale: this.config.autoScale
        });
    }

    /**
     * Fork workers
     */
    forkWorkers(count) {
        for (let i = 0; i < count; i++) {
            this.forkWorker();
        }
    }

    /**
     * Fork a single worker
     */
    forkWorker() {
        const worker = cluster.fork();
        const workerId = worker.id;

        this.workers.set(workerId, {
            worker,
            pid: worker.process.pid,
            startTime: Date.now(),
            restarts: 0,
            lastRestart: null,
            requests: 0,
            avgResponseTime: 0,
            status: 'starting'
        });

        this.workerStats.set(workerId, {
            cpuUsage: 0,
            memoryUsage: 0,
            requestsPerSecond: 0,
            errors: 0
        });

        logger.info(`👷 Worker ${workerId} (PID: ${worker.process.pid}) starting...`);

        // Worker ready notification
        worker.on('message', (message) => {
            if (message.type === 'worker-ready') {
                const workerInfo = this.workers.get(workerId);
                if (workerInfo) {
                    workerInfo.status = 'ready';
                    logger.info(`✅ Worker ${workerId} ready and serving requests`);
                }
            } else if (message.type === 'worker-stats') {
                this.updateWorkerStats(workerId, message.stats);
            }
        });

        this.metrics.totalWorkers++;
        this.emit('workerStarted', { workerId, pid: worker.process.pid });

        return worker;
    }

    /**
     * Setup cluster event handlers
     */
    setupClusterEvents() {
        cluster.on('exit', (worker, code, signal) => {
            const workerId = worker.id;
            const workerInfo = this.workers.get(workerId);

            logger.warn(`💀 Worker ${workerId} died (${signal || code})`);

            if (workerInfo) {
                workerInfo.status = 'dead';
                this.workers.delete(workerId);
                this.workerStats.delete(workerId);
                this.metrics.restarts++;
            }

            // Restart worker if not shutting down
            if (!this.isShuttingDown) {
                if (this.shouldRestartWorker(workerId)) {
                    setTimeout(() => {
                        logger.info(`🔄 Restarting worker ${workerId}...`);
                        this.forkWorker();
                    }, this.config.restartDelay);
                } else {
                    logger.error(`❌ Worker ${workerId} restart limit exceeded`);
                }
            }

            this.emit('workerDied', { workerId, code, signal });
        });

        cluster.on('disconnect', (worker) => {
            logger.warn(`🔌 Worker ${worker.id} disconnected`);
        });
    }

    /**
     * Check if worker should be restarted
     */
    shouldRestartWorker(workerId) {
        const now = Date.now();
        const workerInfo = this.workers.get(workerId);
        
        if (!workerInfo) return true;

        // Reset restart count if outside restart window
        if (workerInfo.lastRestart && (now - workerInfo.lastRestart) > this.config.restartWindow) {
            workerInfo.restarts = 0;
        }

        return workerInfo.restarts < this.config.maxRestarts;
    }

    /**
     * Update worker statistics
     */
    updateWorkerStats(workerId, stats) {
        const workerStats = this.workerStats.get(workerId);
        if (workerStats) {
            Object.assign(workerStats, stats);
        }

        const workerInfo = this.workers.get(workerId);
        if (workerInfo) {
            workerInfo.requests = stats.requests || 0;
            workerInfo.avgResponseTime = stats.avgResponseTime || 0;
        }
    }

    /**
     * Start health monitoring
     */
    startHealthMonitoring() {
        this.healthCheckTimer = setInterval(() => {
            this.performHealthCheck();
        }, this.config.healthCheckInterval);

        logger.info('💊 Health monitoring started');
    }

    /**
     * Perform comprehensive health check
     */
    async performHealthCheck() {
        try {
            const systemStats = this.getSystemStats();
            this.metrics.cpuUsage = systemStats.cpu;
            this.metrics.memoryUsage = systemStats.memory;

            // Check individual workers
            const unhealthyWorkers = [];
            
            for (const [workerId, workerInfo] of this.workers) {
                if (workerInfo.status === 'ready') {
                    // Send health check ping
                    workerInfo.worker.send({ type: 'health-check' });
                    
                    // Check if worker is responding (timeout-based)
                    const isResponsive = await this.checkWorkerResponsiveness(workerId);
                    if (!isResponsive) {
                        unhealthyWorkers.push(workerId);
                    }
                }
            }

            // Restart unhealthy workers
            for (const workerId of unhealthyWorkers) {
                logger.warn(`🏥 Restarting unhealthy worker ${workerId}`);
                this.restartWorker(workerId);
            }

            this.emit('healthCheck', {
                systemStats,
                workers: this.workers.size,
                unhealthyWorkers: unhealthyWorkers.length
            });

        } catch (error) {
            logger.error('Health check failed:', error);
        }
    }

    /**
     * Check worker responsiveness
     */
    async checkWorkerResponsiveness(workerId) {
        return new Promise((resolve) => {
            const worker = this.workers.get(workerId)?.worker;
            if (!worker) {
                resolve(false);
                return;
            }

            let responded = false;
            const timeout = setTimeout(() => {
                if (!responded) {
                    resolve(false);
                }
            }, 5000); // 5 second timeout

            const responseHandler = (message) => {
                if (message.type === 'health-response') {
                    responded = true;
                    clearTimeout(timeout);
                    worker.off('message', responseHandler);
                    resolve(true);
                }
            };

            worker.on('message', responseHandler);
            worker.send({ type: 'health-check', timestamp: Date.now() });
        });
    }

    /**
     * Start auto-scaling based on system metrics
     */
    startAutoScaling() {
        this.scaleCheckTimer = setInterval(() => {
            this.checkAutoScale();
        }, 30000); // Check every 30 seconds

        logger.info('📈 Auto-scaling enabled');
    }

    /**
     * Check if auto-scaling is needed
     */
    checkAutoScale() {
        const currentWorkers = this.workers.size;
        const systemStats = this.getSystemStats();

        // Scale up conditions
        if (currentWorkers < this.config.maxWorkers && 
            (systemStats.cpu > this.config.cpuThreshold || 
             systemStats.memory > this.config.memoryThreshold)) {
            
            logger.info(`📈 Auto-scaling UP: CPU ${systemStats.cpu}%, Memory ${systemStats.memory}%`);
            this.forkWorker();
            this.emit('autoScale', { action: 'up', workers: currentWorkers + 1 });
        }
        
        // Scale down conditions (conservative)
        else if (currentWorkers > this.config.minWorkers && 
                 systemStats.cpu < 50 && 
                 systemStats.memory < 50 && 
                 currentWorkers > this.config.workers) {
            
            logger.info(`📉 Auto-scaling DOWN: CPU ${systemStats.cpu}%, Memory ${systemStats.memory}%`);
            this.terminateWorker();
            this.emit('autoScale', { action: 'down', workers: currentWorkers - 1 });
        }
    }

    /**
     * Get system statistics
     */
    getSystemStats() {
        const memUsage = process.memoryUsage();
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const usedMem = totalMem - freeMem;

        return {
            cpu: this.getCPUUsage(),
            memory: Math.round((usedMem / totalMem) * 100),
            totalMemory: totalMem,
            usedMemory: usedMem,
            freeMemory: freeMem,
            processMemory: memUsage,
            uptime: process.uptime(),
            loadAverage: os.loadavg()
        };
    }

    /**
     * Get CPU usage percentage
     */
    getCPUUsage() {
        const cpus = os.cpus();
        let totalIdle = 0;
        let totalTick = 0;

        cpus.forEach(cpu => {
            for (const type in cpu.times) {
                totalTick += cpu.times[type];
            }
            totalIdle += cpu.times.idle;
        });

        return Math.round(100 - ~~(100 * totalIdle / totalTick));
    }

    /**
     * Restart a specific worker
     */
    restartWorker(workerId) {
        const workerInfo = this.workers.get(workerId);
        if (workerInfo) {
            workerInfo.worker.kill('SIGTERM');
            workerInfo.restarts++;
            workerInfo.lastRestart = Date.now();
        }
    }

    /**
     * Gracefully terminate a worker (for scaling down)
     */
    terminateWorker() {
        // Find the worker with the least load
        let targetWorker = null;
        let minRequests = Infinity;

        for (const [workerId, workerInfo] of this.workers) {
            if (workerInfo.requests < minRequests) {
                minRequests = workerInfo.requests;
                targetWorker = workerId;
            }
        }

        if (targetWorker) {
            logger.info(`📉 Gracefully terminating worker ${targetWorker}`);
            this.restartWorker(targetWorker);
        }
    }

    /**
     * Setup graceful shutdown
     */
    setupGracefulShutdown() {
        const gracefulShutdown = async (signal) => {
            logger.info(`🛑 Received ${signal}, starting graceful shutdown...`);
            this.isShuttingDown = true;

            // Clear timers
            if (this.healthCheckTimer) clearInterval(this.healthCheckTimer);
            if (this.scaleCheckTimer) clearInterval(this.scaleCheckTimer);

            // Disconnect all workers
            const shutdownPromises = [];
            
            for (const [workerId, workerInfo] of this.workers) {
                shutdownPromises.push(
                    this.gracefulWorkerShutdown(workerInfo.worker, workerId)
                );
            }

            try {
                await Promise.allSettled(shutdownPromises);
                logger.info('✅ All workers shut down gracefully');
            } catch (error) {
                logger.error('Error during graceful shutdown:', error);
            }

            process.exit(0);
        };

        process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
        process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    }

    /**
     * Gracefully shutdown a worker
     */
    async gracefulWorkerShutdown(worker, workerId) {
        return new Promise((resolve) => {
            const timeout = setTimeout(() => {
                logger.warn(`⏰ Worker ${workerId} shutdown timeout, force killing...`);
                worker.kill('SIGKILL');
                resolve();
            }, this.config.gracefulShutdownTimeout);

            worker.on('exit', () => {
                clearTimeout(timeout);
                logger.info(`✅ Worker ${workerId} shut down gracefully`);
                resolve();
            });

            worker.send({ type: 'shutdown' });
            worker.disconnect();
        });
    }

    /**
     * Get cluster status
     */
    getClusterStatus() {
        const workers = Array.from(this.workers.entries()).map(([id, info]) => ({
            id,
            pid: info.pid,
            status: info.status,
            startTime: info.startTime,
            uptime: Date.now() - info.startTime,
            requests: info.requests,
            avgResponseTime: info.avgResponseTime,
            restarts: info.restarts,
            stats: this.workerStats.get(id)
        }));

        return {
            cluster: {
                isPrimary: cluster.isPrimary,
                totalWorkers: this.workers.size,
                activeWorkers: workers.filter(w => w.status === 'ready').length,
                autoScaling: this.config.autoScale,
                uptime: Date.now() - this.metrics.uptime
            },
            workers,
            metrics: {
                ...this.metrics,
                systemStats: this.getSystemStats()
            },
            configuration: {
                maxWorkers: this.config.maxWorkers,
                minWorkers: this.config.minWorkers,
                cpuThreshold: this.config.cpuThreshold,
                memoryThreshold: this.config.memoryThreshold
            }
        };
    }
}

/**
 * Worker process setup
 */
export function setupWorkerProcess() {
    if (cluster.isWorker) {
        logger.info(`👷 Worker ${cluster.worker.id} (PID: ${process.pid}) starting...`);

        // Send ready notification
        process.send({ type: 'worker-ready' });

        // Handle health checks
        process.on('message', (message) => {
            if (message.type === 'health-check') {
                process.send({ 
                    type: 'health-response', 
                    timestamp: Date.now(),
                    workerId: cluster.worker.id
                });
            } else if (message.type === 'shutdown') {
                logger.info(`🛑 Worker ${cluster.worker.id} received shutdown signal`);
                // Implement graceful shutdown for worker
                setTimeout(() => {
                    process.exit(0);
                }, 1000);
            }
        });

        // Send periodic stats
        setInterval(() => {
            const memUsage = process.memoryUsage();
            process.send({
                type: 'worker-stats',
                stats: {
                    requests: global.requestCount || 0,
                    avgResponseTime: global.avgResponseTime || 0,
                    memoryUsage: memUsage,
                    uptime: process.uptime()
                }
            });
        }, 10000);
    }
}

export default ClusterManager;