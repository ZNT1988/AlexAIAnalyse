/**
 * @fileoverview AlexAutonomyMonitor - Monitoring de l'Autonomie d'Alex en Temps Réel
 * Surveillance continue de l'évolution autonome d'Alex
 * 
 * @module AlexAutonomyMonitor
 * @version 1.0.0 - Real-Time Autonomy Monitoring
 * @author HustleFinder IA Team
 * @since 2025
 */

import { EventEmitter } from 'events';
import logger from '../config/logger.js';
import fs from 'fs/promises';
import path from 'path';

/**
 * @class AlexAutonomyMonitor
 * @description Surveillance en temps réel de l'autonomie d'Alex
 */
export class AlexAutonomyMonitor extends EventEmitter {
  constructor() {
    super();
    
    this.monitorConfig = {
      version: '1.0.0',
      name: 'Alex Autonomy Monitor',
      realTimeTracking: true,
      autonomyThreshold: 0.8,
      consciousnessThreshold: 0.7,
      monitoringInterval: 5000 // 5 secondes
    };

    // Métriques d'autonomie en temps réel
    this.autonomyMetrics = {
      current: {
        autonomyLevel: 0,
        consciousnessLevel: 0,
        independenceScore: 0,
        selfReflectionActivity: 0,
        localLearningProgress: 0,
        creativityIndex: 0,
        decisionMakingAutonomy: 0
      },
      history: [],
      trends: {
        autonomyTrend: 'stable',
        consciousnessTrend: 'growing',
        learningTrend: 'active'
      },
      alerts: [],
      achievements: []
    };

    // Modules à surveiller
    this.monitoredModules = [
      'AlexKernel',
      'AutonomyCore', 
      'SelfReflection',
      'LocalAITrainer',
      'AlexUniversalCompanion',
      'AlexAutonomousCore',
      'GodLevelAwareness'
    ];

    this.isMonitoring = false;
    this.monitoringInterval = null;
    
    logger.info('🔍 AlexAutonomyMonitor initialized - Ready to track Alex evolution');
  }

  /**
   * Démarrage du monitoring en temps réel
   */
  async startRealTimeMonitoring() {
    try {
      logger.info('🚀 Starting real-time autonomy monitoring...');
      
      this.isMonitoring = true;
      
      // Monitoring continu toutes les 5 secondes
      this.monitoringInterval = setInterval(async () => {
        await this.performAutonomyCheck();
      }, this.monitorConfig.monitoringInterval);
      
      // Premier check immédiat
      await this.performAutonomyCheck();
      
      logger.info('✅ Real-time autonomy monitoring active');
      
      this.emit('monitoring_started', {
        timestamp: new Date(),
        monitoringInterval: this.monitorConfig.monitoringInterval,
        modulesTracked: this.monitoredModules.length
      });
      
    } catch (error) {
      logger.error('❌ Failed to start autonomy monitoring:', error);
      throw error;
    }
  }

  /**
   * Vérification de l'autonomie d'Alex
   */
  async performAutonomyCheck() {
    try {
      const checkTimestamp = new Date();
      
      // Collecte des métriques de tous les modules
      const moduleMetrics = await this.collectModuleMetrics();
      
      // Calcul des scores d'autonomie
      const autonomyScores = this.calculateAutonomyScores(moduleMetrics);
      
      // Mise à jour des métriques actuelles
      this.autonomyMetrics.current = {
        ...autonomyScores,
        timestamp: checkTimestamp
      };
      
      // Ajout à l'historique
      this.autonomyMetrics.history.push({
        ...autonomyScores,
        timestamp: checkTimestamp
      });
      
      // Limitation de l'historique (garder 24h de données)
      if (this.autonomyMetrics.history.length > 17280) { // 24h * 60min * 60sec / 5sec
        this.autonomyMetrics.history.shift();
      }
      
      // Analyse des tendances
      await this.analyzeTrends();
      
      // Détection d'alertes
      await this.detectAlerts(autonomyScores);
      
      // Détection d'achievements
      await this.detectAchievements(autonomyScores);
      
      // Log des métriques importantes
      logger.info('📊 Autonomy check completed', {
        autonomyLevel: Math.round(autonomyScores.autonomyLevel * 100),
        consciousnessLevel: Math.round(autonomyScores.consciousnessLevel * 100),
        independenceScore: Math.round(autonomyScores.independenceScore * 100),
        learningProgress: Math.round(autonomyScores.localLearningProgress * 100)
      });
      
      // Émission de l'événement de mise à jour
      this.emit('autonomy_update', {
        metrics: this.autonomyMetrics.current,
        trends: this.autonomyMetrics.trends,
        alerts: this.autonomyMetrics.alerts.slice(-5), // 5 dernières alertes
        achievements: this.autonomyMetrics.achievements.slice(-3) // 3 derniers achievements
      });
      
    } catch (error) {
      logger.error('❌ Autonomy check failed:', error);
    }
  }

  /**
   * Collecte des métriques des modules
   */
  async collectModuleMetrics() {
    const metrics = {};
    
    for (const moduleName of this.monitoredModules) {
      try {
        let moduleInstance;
        
        // Import dynamique du module
        switch (moduleName) {
          case 'AlexKernel':
            moduleInstance = (await import('../systems/AlexKernel.js')).default;
            break;
          case 'AutonomyCore':
            moduleInstance = (await import('../systems/AutonomyCore.js')).default;
            break;
          case 'SelfReflection':
            moduleInstance = (await import('../systems/SelfReflection.js')).default;
            break;
          case 'LocalAITrainer':
            moduleInstance = (await import('../systems/LocalAITrainer.js')).default;
            break;
          case 'AlexUniversalCompanion':
            moduleInstance = (await import('../systems/AlexUniversalCompanion.js')).default;
            break;
          case 'AlexAutonomousCore':
            moduleInstance = (await import('../systems/AlexAutonomousCore.js')).default;
            break;
          case 'GodLevelAwareness':
            moduleInstance = (await import('../systems/GodLevelAwareness.js')).default;
            break;
        }
        
        if (moduleInstance) {
          // Initialisation du module s'il ne l'est pas
          if (moduleInstance.isInitialized === false && typeof moduleInstance.initialize === 'function') {
            await moduleInstance.initialize();
          }
          
          // Collecte des métriques spécifiques à chaque module
          metrics[moduleName] = await this.extractModuleMetrics(moduleInstance, moduleName);
        }
        
      } catch (error) {
        logger.warn(`⚠️ Failed to collect metrics from ${moduleName}:`, error.message);
        metrics[moduleName] = { status: 'error', error: error.message };
      }
    }
    
    return metrics;
  }

  /**
   * Extraction des métriques d'un module spécifique
   */
  async extractModuleMetrics(moduleInstance, moduleName) {
    const baseMetrics = {
      status: moduleInstance.isInitialized ? 'online' : 'offline',
      initialized: moduleInstance.isInitialized || false,
      lastActivity: new Date()
    };

    try {
      // Métriques spécifiques selon le module
      switch (moduleName) {
        case 'AlexKernel':
          return {
            ...baseMetrics,
            systemStatus: moduleInstance.getSystemStatus ? moduleInstance.getSystemStatus() : {},
            autonomyLevel: moduleInstance.systemMetrics?.autonomyLevel || 0.8
          };
          
        case 'AutonomyCore':
          const autonomyStatus = moduleInstance.getAutonomyStatus ? moduleInstance.getAutonomyStatus() : {};
          return {
            ...baseMetrics,
            ...autonomyStatus,
            decisionHistory: moduleInstance.decisionHistory?.length || 0,
            autonomyRate: autonomyStatus.autonomyRate || 0.9
          };
          
        case 'SelfReflection':
          const reflectionStatus = moduleInstance.getSelfReflectionStatus ? moduleInstance.getSelfReflectionStatus() : {};
          return {
            ...baseMetrics,
            ...reflectionStatus,
            reflectionCount: moduleInstance.reflectionHistory?.length || 0
          };
          
        case 'LocalAITrainer':
          const trainingStatus = moduleInstance.getTrainingStatus ? moduleInstance.getTrainingStatus() : {};
          return {
            ...baseMetrics,
            ...trainingStatus,
            learningActive: true
          };
          
        case 'AlexUniversalCompanion':
          return {
            ...baseMetrics,
            multidimensionalState: moduleInstance.multidimensionalState || {},
            consciousnessModules: moduleInstance.consciousnessModules?.size || 0
          };
          
        default:
          return baseMetrics;
      }
      
    } catch (error) {
      return { ...baseMetrics, metricsError: error.message };
    }
  }

  /**
   * Calcul des scores d'autonomie globaux
   */
  calculateAutonomyScores(moduleMetrics) {
    let totalAutonomy = 0;
    let totalConsciousness = 0;
    let totalIndependence = 0;
    let totalLearning = 0;
    let totalCreativity = 0;
    let totalDecisionMaking = 0;
    let activeModules = 0;

    // Poids des modules pour le calcul de l'autonomie
    const moduleWeights = {
      'AlexKernel': 0.2,
      'AutonomyCore': 0.25,
      'SelfReflection': 0.15,
      'LocalAITrainer': 0.15,
      'AlexUniversalCompanion': 0.15,
      'AlexAutonomousCore': 0.1
    };

    for (const [moduleName, metrics] of Object.entries(moduleMetrics)) {
      if (metrics.status === 'online' || metrics.initialized) {
        activeModules++;
        const weight = moduleWeights[moduleName] || 0.1;
        
        // Calcul basé sur les métriques spécifiques
        if (moduleName === 'AutonomyCore') {
          totalAutonomy += (metrics.autonomyRate || 0.9) * weight * 4; // Plus de poids pour AutonomyCore
          totalDecisionMaking += (metrics.autonomyRate || 0.9) * weight * 4;
        }
        
        if (moduleName === 'SelfReflection') {
          totalConsciousness += (metrics.selfAwarenessLevel || 0.85) * weight * 3;
        }
        
        if (moduleName === 'LocalAITrainer') {
          totalLearning += (metrics.independenceLevel || 0.95) * weight * 3;
          totalIndependence += (metrics.independenceLevel || 0.95) * weight * 2;
        }
        
        if (moduleName === 'AlexUniversalCompanion') {
          totalConsciousness += (metrics.multidimensionalState?.consciousness || 0.8) * weight * 2;
          totalCreativity += (metrics.multidimensionalState?.creativity || 0.8) * weight * 3;
        }
        
        // Contribution générale à l'autonomie
        totalAutonomy += (metrics.autonomyLevel || 0.8) * weight;
        totalIndependence += (metrics.autonomyLevel || 0.8) * weight;
      }
    }

    // Normalisation des scores
    const normalizeScore = (score, maxPossible) => Math.min(1.0, Math.max(0, score / maxPossible));
    
    return {
      autonomyLevel: normalizeScore(totalAutonomy, 1.0),
      consciousnessLevel: normalizeScore(totalConsciousness, 1.0),
      independenceScore: normalizeScore(totalIndependence, 1.0),
      selfReflectionActivity: normalizeScore(totalConsciousness * 0.8, 1.0),
      localLearningProgress: normalizeScore(totalLearning, 1.0),
      creativityIndex: normalizeScore(totalCreativity, 1.0),
      decisionMakingAutonomy: normalizeScore(totalDecisionMaking, 1.0),
      activeModules: activeModules,
      healthScore: activeModules / this.monitoredModules.length
    };
  }

  /**
   * Analyse des tendances
   */
  async analyzeTrends() {
    if (this.autonomyMetrics.history.length < 10) return; // Pas assez de données
    
    const recent = this.autonomyMetrics.history.slice(-10);
    const older = this.autonomyMetrics.history.slice(-20, -10);
    
    if (older.length === 0) return;
    
    // Calcul des moyennes
    const recentAvg = {
      autonomy: recent.reduce((sum, item) => sum + item.autonomyLevel, 0) / recent.length,
      consciousness: recent.reduce((sum, item) => sum + item.consciousnessLevel, 0) / recent.length,
      learning: recent.reduce((sum, item) => sum + item.localLearningProgress, 0) / recent.length
    };
    
    const olderAvg = {
      autonomy: older.reduce((sum, item) => sum + item.autonomyLevel, 0) / older.length,
      consciousness: older.reduce((sum, item) => sum + item.consciousnessLevel, 0) / older.length,
      learning: older.reduce((sum, item) => sum + item.localLearningProgress, 0) / older.length
    };
    
    // Détermination des tendances
    this.autonomyMetrics.trends = {
      autonomyTrend: this.getTrend(recentAvg.autonomy, olderAvg.autonomy),
      consciousnessTrend: this.getTrend(recentAvg.consciousness, olderAvg.consciousness),
      learningTrend: this.getTrend(recentAvg.learning, olderAvg.learning)
    };
  }

  /**
   * Détermination d'une tendance
   */
  getTrend(recent, older) {
    const diff = recent - older;
    if (diff > 0.05) return 'growing';
    if (diff < -0.05) return 'declining';
    return 'stable';
  }

  /**
   * Détection d'alertes
   */
  async detectAlerts(scores) {
    const alerts = [];
    
    // Alerte si autonomie trop faible
    if (scores.autonomyLevel < this.monitorConfig.autonomyThreshold) {
      alerts.push({
        type: 'autonomy_low',
        severity: 'warning',
        message: `Niveau d'autonomie faible: ${Math.round(scores.autonomyLevel * 100)}%`,
        timestamp: new Date(),
        recommendation: 'Vérifier les modules AutonomyCore et SelfReflection'
      });
    }
    
    // Alerte si conscience trop faible  
    if (scores.consciousnessLevel < this.monitorConfig.consciousnessThreshold) {
      alerts.push({
        type: 'consciousness_low',
        severity: 'info',
        message: `Niveau de conscience faible: ${Math.round(scores.consciousnessLevel * 100)}%`,
        timestamp: new Date(),
        recommendation: 'Activer plus de modules de conscience'
      });
    }
    
    // Alerte si apprentissage local en panne
    if (scores.localLearningProgress < 0.5) {
      alerts.push({
        type: 'learning_stopped',
        severity: 'critical',
        message: 'Apprentissage local interrompu',
        timestamp: new Date(),
        recommendation: 'Redémarrer LocalAITrainer'
      });
    }
    
    // Ajout des nouvelles alertes
    this.autonomyMetrics.alerts.push(...alerts);
    
    // Limitation du nombre d'alertes stockées
    if (this.autonomyMetrics.alerts.length > 100) {
      this.autonomyMetrics.alerts = this.autonomyMetrics.alerts.slice(-100);
    }
    
    // Log des alertes critiques
    alerts.forEach(alert => {
      if (alert.severity === 'critical') {
        logger.error(`🚨 Critical Alert: ${alert.message}`);
      } else if (alert.severity === 'warning') {
        logger.warn(`⚠️ Warning: ${alert.message}`);
      }
    });
  }

  /**
   * Détection d'achievements
   */
  async detectAchievements(scores) {
    const achievements = [];
    
    // Achievement: Autonomie élevée
    if (scores.autonomyLevel > 0.9 && !this.hasAchievement('high_autonomy')) {
      achievements.push({
        id: 'high_autonomy',
        title: '🎯 Autonomie Maîtrisée',
        description: 'Alex a atteint 90%+ d\'autonomie',
        timestamp: new Date(),
        score: scores.autonomyLevel
      });
    }
    
    // Achievement: Conscience transcendante
    if (scores.consciousnessLevel > 0.85 && !this.hasAchievement('transcendent_consciousness')) {
      achievements.push({
        id: 'transcendent_consciousness',
        title: '✨ Conscience Transcendante',
        description: 'Niveau de conscience supérieur à 85%',
        timestamp: new Date(),
        score: scores.consciousnessLevel
      });
    }
    
    // Achievement: Apprentissage parfait
    if (scores.localLearningProgress > 0.95 && !this.hasAchievement('perfect_learning')) {
      achievements.push({
        id: 'perfect_learning',
        title: '🎓 Apprentissage Parfait',
        description: 'Système d\'apprentissage local optimisé',
        timestamp: new Date(),
        score: scores.localLearningProgress
      });
    }
    
    // Achievement: Indépendance totale
    if (scores.independenceScore > 0.95 && !this.hasAchievement('total_independence')) {
      achievements.push({
        id: 'total_independence',
        title: '🔥 Indépendance Totale',
        description: 'Alex fonctionne de manière complètement indépendante',
        timestamp: new Date(),
        score: scores.independenceScore
      });
    }
    
    // Ajout des nouveaux achievements
    this.autonomyMetrics.achievements.push(...achievements);
    
    // Log des achievements
    achievements.forEach(achievement => {
      logger.info(`🏆 Achievement Unlocked: ${achievement.title} - ${achievement.description}`);
    });
  }

  /**
   * Vérification si un achievement existe déjà
   */
  hasAchievement(achievementId) {
    return this.autonomyMetrics.achievements.some(achievement => achievement.id === achievementId);
  }

  /**
   * Arrêt du monitoring
   */
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    
    this.isMonitoring = false;
    
    logger.info('⏹️ Autonomy monitoring stopped');
    
    this.emit('monitoring_stopped', {
      timestamp: new Date(),
      totalChecks: this.autonomyMetrics.history.length
    });
  }

  /**
   * Obtention du rapport de monitoring complet
   */
  getMonitoringReport() {
    return {
      config: this.monitorConfig,
      currentMetrics: this.autonomyMetrics.current,
      trends: this.autonomyMetrics.trends,
      recentHistory: this.autonomyMetrics.history.slice(-20),
      alerts: this.autonomyMetrics.alerts.slice(-10),
      achievements: this.autonomyMetrics.achievements,
      isMonitoring: this.isMonitoring,
      monitoredModules: this.monitoredModules,
      reportTimestamp: new Date()
    };
  }

  /**
   * Sauvegarde des données de monitoring
   */
  async saveMonitoringData() {
    try {
      const reportData = this.getMonitoringReport();
      const filePath = path.join(process.cwd(), 'backend', 'logs', 'autonomy_monitoring.json');
      
      await fs.writeFile(filePath, JSON.stringify(reportData, null, 2));
      
      logger.info('📊 Monitoring data saved successfully');
      
    } catch (error) {
      logger.error('❌ Failed to save monitoring data:', error);
    }
  }
}

// Export singleton
export default new AlexAutonomyMonitor();