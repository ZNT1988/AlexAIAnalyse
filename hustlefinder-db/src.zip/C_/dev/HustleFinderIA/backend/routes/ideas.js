import express from 'express';
import { query } from '../config/database.js';
import logger from '../config/logger.js';
import Joi from 'joi';

const router = express.Router();

// Validation schemas
const ideaSchema = Joi.object({
  title: Joi.string().max(255).required(),
  content: Joi.string().required(),
  category: Joi.string().max(100).optional(),
  implementation_difficulty: Joi.number().integer().min(1).max(10).optional(),
  market_potential: Joi.number().integer().min(1).max(10).optional(),
  tags: Joi.array().items(Joi.string()).optional()
});

const updateIdeaSchema = Joi.object({
  title: Joi.string().max(255).optional(),
  content: Joi.string().optional(),
  category: Joi.string().max(100).optional(),
  implementation_difficulty: Joi.number().integer().min(1).max(10).optional(),
  market_potential: Joi.number().integer().min(1).max(10).optional(),
  is_favorite: Joi.boolean().optional(),
  tags: Joi.array().items(Joi.string()).optional()
});

// Helper function to get user ID from Clerk ID
async function getUserId(clerkId) {
  const result = await query('SELECT id FROM users WHERE clerk_id = $1', [clerkId]);
  if (result.rows.length === 0) {
    throw new Error('User not found');
  }
  return result.rows[0].id;
}

// Get all ideas for the authenticated user
router.get('/', async (req, res) => {
  try {
    const userId = await getUserId(req.auth.userId);
    const { category, favorite, limit = 50, offset = 0 } = req.query;
    
    let queryText = `
      SELECT * FROM ideas 
      WHERE user_id = $1
    `;
    const params = [userId];
    let paramIndex = 2;
    
    if (category) {
      queryText += ` AND category = $${paramIndex}`;
      params.push(category);
      paramIndex++;
    }
    
    if (favorite === 'true') {
      queryText += ` AND is_favorite = true`;
    }
    
    queryText += ` ORDER BY created_at DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    params.push(parseInt(limit), parseInt(offset));
    
    const result = await query(queryText, params);
    
    // Get total count
    const countResult = await query(
      'SELECT COUNT(*) FROM ideas WHERE user_id = $1',
      [userId]
    );
    
    res.json({
      ideas: result.rows,
      total: parseInt(countResult.rows[0].count),
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
    
  } catch (error) {
    logger.error('Error fetching ideas:', error);
    res.status(500).json({ error: 'Failed to fetch ideas' });
  }
});

// Get a specific idea
router.get('/:id', async (req, res) => {
  try {
    const userId = await getUserId(req.auth.userId);
    const ideaId = req.params.id;
    
    const result = await query(
      'SELECT * FROM ideas WHERE id = $1 AND user_id = $2',
      [ideaId, userId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    res.json({ idea: result.rows[0] });
    
  } catch (error) {
    logger.error('Error fetching idea:', error);
    res.status(500).json({ error: 'Failed to fetch idea' });
  }
});

// Create a new idea
router.post('/', async (req, res) => {
  try {
    // Validate input
    const { error, value } = ideaSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    
    const userId = await getUserId(req.auth.userId);
    const { title, content, category, implementation_difficulty, market_potential, tags } = value;
    
    // Calculate a basic match score (can be enhanced with AI later)
    const match_score = Math.floor(Math.random() * 100); // Placeholder
    
    const result = await query(
      `INSERT INTO ideas (
        user_id, title, content, category, match_score, 
        implementation_difficulty, market_potential, tags
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [userId, title, content, category, match_score, implementation_difficulty, market_potential, tags]
    );
    
    logger.info(`New idea created: ${title} for user ${userId}`);
    res.status(201).json({ idea: result.rows[0] });
    
  } catch (error) {
    logger.error('Error creating idea:', error);
    res.status(500).json({ error: 'Failed to create idea' });
  }
});

// Update an idea
router.put('/:id', async (req, res) => {
  try {
    // Validate input
    const { error, value } = updateIdeaSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }
    
    const userId = await getUserId(req.auth.userId);
    const ideaId = req.params.id;
    
    // Build dynamic update query
    const updates = [];
    const params = [];
    let paramIndex = 1;
    
    Object.entries(value).forEach(([key, val]) => {
      if (val !== undefined) {
        updates.push(`${key} = $${paramIndex}`);
        params.push(val);
        paramIndex++;
      }
    });
    
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }
    
    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    params.push(ideaId, userId);
    
    const queryText = `
      UPDATE ideas 
      SET ${updates.join(', ')}
      WHERE id = $${paramIndex} AND user_id = $${paramIndex + 1}
      RETURNING *
    `;
    
    const result = await query(queryText, params);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    res.json({ idea: result.rows[0] });
    
  } catch (error) {
    logger.error('Error updating idea:', error);
    res.status(500).json({ error: 'Failed to update idea' });
  }
});

// Delete an idea
router.delete('/:id', async (req, res) => {
  try {
    const userId = await getUserId(req.auth.userId);
    const ideaId = req.params.id;
    
    const result = await query(
      'DELETE FROM ideas WHERE id = $1 AND user_id = $2 RETURNING *',
      [ideaId, userId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    logger.info(`Idea deleted: ${ideaId} for user ${userId}`);
    res.json({ message: 'Idea deleted successfully' });
    
  } catch (error) {
    logger.error('Error deleting idea:', error);
    res.status(500).json({ error: 'Failed to delete idea' });
  }
});

// Get ideas statistics
router.get('/stats/overview', async (req, res) => {
  try {
    const userId = await getUserId(req.auth.userId);
    
    const stats = await Promise.all([
      query('SELECT COUNT(*) as total FROM ideas WHERE user_id = $1', [userId]),
      query('SELECT COUNT(*) as favorites FROM ideas WHERE user_id = $1 AND is_favorite = true', [userId]),
      query('SELECT category, COUNT(*) as count FROM ideas WHERE user_id = $1 GROUP BY category', [userId]),
      query('SELECT AVG(match_score) as avg_score FROM ideas WHERE user_id = $1', [userId])
    ]);
    
    res.json({
      total_ideas: parseInt(stats[0].rows[0].total),
      favorite_ideas: parseInt(stats[1].rows[0].favorites),
      categories: stats[2].rows,
      average_match_score: parseFloat(stats[3].rows[0].avg_score) || 0
    });
    
  } catch (error) {
    logger.error('Error fetching ideas stats:', error);
    res.status(500).json({ error: 'Failed to fetch ideas statistics' });
  }
});

export default router;