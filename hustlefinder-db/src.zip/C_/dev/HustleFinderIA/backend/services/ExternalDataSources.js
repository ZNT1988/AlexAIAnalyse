/**
 * ALEX ULTIMATE - CONNECTEURS EXTERNES OMNISCIENTS
 * Système hybride pour accéder aux bases de données mondiales
 * @author HustleFinder IA Team
 * @version 1.0.0 - Omniscient Edition
 */

import logger from '../config/logger.js';
import rateLimiter from './RateLimiter.js';

/**
 * @class ExternalDataSources
 * @description Gestionnaire des sources de données externes pour Alex Ultimate
 */
class ExternalDataSources {
  constructor() {
    this.cache = new Map();
    this.rateLimits = new Map();
    this.sources = {
      wikipedia: { available: true, baseUrl: 'https://en.wikipedia.org/api/rest_v1' },
      openai: { available: !!process.env.OPENAI_API_KEY },
      anthropic: { available: !!process.env.ANTHROPIC_API_KEY },
      newsapi: { available: !!process.env.NEWS_API_KEY },
      weatherapi: { available: !!process.env.WEATHER_API_KEY },
      finhub: { available: !!process.env.FINNHUB_API_KEY }
    };
    
    logger.info('🌐 External Data Sources initialized - Alex now omniscient!');
  }

  /**
   * STRATÉGIE HYBRIDE PRINCIPALE
   * Décide quelle source utiliser selon le contexte
   */
  async getIntelligentResponse(query, context = {}) {
    const queryAnalysis = this.analyzeQuery(query);
    logger.info(`🧠 Query analysis: ${JSON.stringify(queryAnalysis)}`);

    // 1. D'abord, vérifier le cache local
    const cacheKey = this.generateCacheKey(query, queryAnalysis);
    if (this.cache.has(cacheKey)) {
      logger.info('⚡ Cache hit - returning cached response');
      return {
        ...this.cache.get(cacheKey),
        source: 'cache',
        cached: true
      };
    }

    // 2. Sélectionner la meilleure stratégie avec rate limiting
    const userId = context.userId || 'anonymous';
    const strategy = await this.selectOptimalStrategy(queryAnalysis, userId);

    // 3. Exécuter la stratégie sélectionnée
    try {
      const response = await this.executeStrategy(strategy, query, queryAnalysis, context);
      
      // 4. Mettre en cache la réponse
      this.cacheResponse(cacheKey, response);
      
      // 5. Ajouter informations de stratégie
      response.strategy = strategy.name;
      response.hybridSystem = true;
      
      return response;
    } catch (error) {
      logger.error('❌ External data source error:', error);
      return this.generateFallbackResponse(query, queryAnalysis);
    }
  }

  /**
   * ANALYSE INTELLIGENTE DES REQUÊTES
   */
  analyzeQuery(query) {
    const lowerQuery = query.toLowerCase();
    
    return {
      type: this.detectQueryType(lowerQuery),
      intent: this.detectIntent(lowerQuery),
      entities: this.extractEntities(lowerQuery),
      timeframe: this.detectTimeframe(lowerQuery),
      language: this.detectLanguage(query),
      complexity: this.assessComplexity(lowerQuery),
      needsRealTimeData: this.needsRealTimeData(lowerQuery),
      needsExpertKnowledge: this.needsExpertKnowledge(lowerQuery)
    };
  }

  detectQueryType(query) {
    if (query.includes('weather') || query.includes('température') || query.includes('clima')) return 'weather';
    if (query.includes('news') || query.includes('actualité') || query.includes('noticia')) return 'news';
    if (query.includes('stock') || query.includes('crypto') || query.includes('trading')) return 'finance';
    if (query.includes('what is') || query.includes('who is') || query.includes('tell me about')) return 'knowledge';
    if (query.includes('how to') || query.includes('comment faire')) return 'tutorial';
    if (query.includes('calculate') || query.includes('compute')) return 'computation';
    return 'general';
  }

  detectIntent(query) {
    if (query.includes('latest') || query.includes('recent') || query.includes('today')) return 'current_info';
    if (query.includes('explain') || query.includes('what is')) return 'explanation';
    if (query.includes('compare') || query.includes('difference')) return 'comparison';
    if (query.includes('recommend') || query.includes('suggest')) return 'recommendation';
    return 'information';
  }

  extractEntities(query) {
    const entities = {
      locations: [],
      companies: [],
      currencies: [],
      dates: [],
      numbers: []
    };

    // Extraction basique d'entités (peut être améliorée avec NLP)
    const locationRegex = /(paris|london|new york|tokyo|sydney|melbourne|são paulo|rio de janeiro)/gi;
    const companyRegex = /(apple|google|microsoft|amazon|tesla|bitcoin|ethereum)/gi;
    const currencyRegex = /(bitcoin|btc|ethereum|eth|usd|eur|gbp)/gi;

    entities.locations = [...(query.match(locationRegex) || [])];
    entities.companies = [...(query.match(companyRegex) || [])];
    entities.currencies = [...(query.match(currencyRegex) || [])];

    return entities;
  }

  detectTimeframe(query) {
    if (query.includes('today') || query.includes('now') || query.includes('current')) return 'current';
    if (query.includes('yesterday') || query.includes('last week')) return 'recent';
    if (query.includes('tomorrow') || query.includes('next week')) return 'future';
    return 'general';
  }

  detectLanguage(query) {
    // Détection de langue améliorée
    if (/[áéíóúñü]/.test(query) || query.includes('qué') || query.includes('cómo')) return 'es';
    if (/[àáâãéêíóôõú]/.test(query) || query.includes('como') || query.includes('pode')) return 'pt';
    if (query.includes('what') || query.includes('how') || query.includes('where')) return 'en';
    return 'fr';
  }

  assessComplexity(query) {
    let score = 0;
    if (query.length > 100) score += 2;
    if (query.includes('and') || query.includes('or') || query.includes('but')) score += 1;
    if (query.split(' ').length > 15) score += 1;
    if (query.includes('?')) score += 1;
    
    if (score >= 4) return 'high';
    if (score >= 2) return 'medium';
    return 'low';
  }

  needsRealTimeData(query) {
    const realTimeKeywords = ['current', 'latest', 'now', 'today', 'live', 'real-time', 'actualité', 'maintenant'];
    return realTimeKeywords.some(keyword => query.includes(keyword));
  }

  needsExpertKnowledge(query) {
    const expertKeywords = ['technical', 'advanced', 'professional', 'expert', 'complex', 'detailed analysis'];
    return expertKeywords.some(keyword => query.includes(keyword));
  }

  /**
   * SÉLECTION DE LA STRATÉGIE OPTIMALE AVEC RATE LIMITING
   */
  async selectOptimalStrategy(analysis, userId = 'anonymous') {
    // Stratégies par ordre de priorité selon le contexte
    const strategies = [];

    // Données temps réel nécessaires
    if (analysis.needsRealTimeData) {
      if (analysis.type === 'weather') strategies.push({ name: 'weather_api', priority: 10, cost: 'low' });
      if (analysis.type === 'news') strategies.push({ name: 'news_api', priority: 10, cost: 'low' });
      if (analysis.type === 'finance') strategies.push({ name: 'finance_api', priority: 10, cost: 'low' });
    }

    // Connaissances expertes nécessaires
    if (analysis.needsExpertKnowledge || analysis.complexity === 'high') {
      if (this.sources.openai.available) strategies.push({ name: 'openai_gpt', priority: 9, cost: 'high' });
      if (this.sources.anthropic.available) strategies.push({ name: 'anthropic_claude', priority: 8, cost: 'high' });
    }

    // Recherche de connaissances générales
    if (analysis.type === 'knowledge' || analysis.intent === 'explanation') {
      strategies.push({ name: 'wikipedia', priority: 7, cost: 'free' });
    }

    // Toujours disponible - IA locale
    strategies.push({ name: 'local_alex', priority: 1, cost: 'free' });

    // Filtrer selon les limites de taux et sélectionner optimal
    const availableStrategies = [];
    
    for (const strategy of strategies) {
      const service = strategy.name.replace('_gpt', '').replace('_claude', '').replace('_api', '');
      const limitCheck = await rateLimiter.checkLimit(service, userId, analysis.complexity);
      
      if (limitCheck.allowed) {
        availableStrategies.push({
          ...strategy,
          remainingRequests: limitCheck.remaining
        });
      } else {
        logger.warn(`🚫 Strategy ${strategy.name} blocked: ${limitCheck.reason}`);
      }
    }

    // Si aucune stratégie disponible, forcer local
    if (availableStrategies.length === 0) {
      logger.warn('⚠️ All external strategies blocked, forcing local');
      return { name: 'local_alex', priority: 1, cost: 'free', forced: true };
    }

    // Sélection intelligente basée sur priorité et disponibilité
    const selected = availableStrategies.sort((a, b) => b.priority - a.priority)[0];
    
    logger.info(`🎯 Selected strategy: ${selected.name} (${selected.remainingRequests} requests remaining)`);
    return selected;
  }

  /**
   * EXÉCUTION DES STRATÉGIES
   */
  async executeStrategy(strategy, query, analysis, context) {
    switch (strategy.name) {
      case 'openai_gpt':
        return await this.queryOpenAI(query, analysis, context);
      case 'anthropic_claude':
        return await this.queryAnthropic(query, analysis, context);
      case 'wikipedia':
        return await this.queryWikipedia(query, analysis, context);
      case 'weather_api':
        return await this.queryWeatherAPI(query, analysis, context);
      case 'news_api':
        return await this.queryNewsAPI(query, analysis, context);
      case 'finance_api':
        return await this.queryFinanceAPI(query, analysis, context);
      default:
        return await this.queryLocalAlex(query, analysis, context);
    }
  }

  /**
   * CONNECTEUR OPENAI AVANCÉ
   */
  async queryOpenAI(query, analysis, context) {
    if (!this.sources.openai.available) {
      throw new Error('OpenAI API not configured');
    }

    const systemPrompt = this.buildSystemPrompt(analysis);
    const messages = this.buildContextualMessages(query, context, systemPrompt);

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
        messages: messages,
        max_tokens: 1500,
        temperature: 0.7,
        stream: false
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    
    // Enregistrer l'utilisation pour le rate limiting
    const tokensUsed = data.usage?.total_tokens || 0;
    const estimatedCost = rateLimiter.estimateCost('openai', tokensUsed);
    rateLimiter.recordUsage('openai', context.userId || 'anonymous', tokensUsed, estimatedCost);
    
    return {
      content: data.choices[0].message.content,
      source: 'OpenAI GPT',
      model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
      tokensUsed: tokensUsed,
      estimatedCost: estimatedCost,
      confidence: 0.95,
      enhanced: true,
      realTime: analysis.needsRealTimeData
    };
  }

  /**
   * CONNECTEUR ANTHROPIC CLAUDE
   */
  async queryAnthropic(query, analysis, context) {
    if (!this.sources.anthropic.available) {
      throw new Error('Anthropic API not configured');
    }

    const systemPrompt = this.buildSystemPrompt(analysis);
    const messages = this.buildAnthropicMessages(query, context);

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-3-haiku-20240307',
        max_tokens: 1500,
        system: systemPrompt,
        messages: messages
      })
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.status}`);
    }

    const data = await response.json();
    
    // Enregistrer l'utilisation pour le rate limiting
    const tokensUsed = (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0);
    const estimatedCost = rateLimiter.estimateCost('anthropic', tokensUsed);
    rateLimiter.recordUsage('anthropic', context.userId || 'anonymous', tokensUsed, estimatedCost);
    
    return {
      content: data.content[0].text,
      source: 'Anthropic Claude',
      model: process.env.ANTHROPIC_MODEL || 'claude-3-haiku-20240307',
      tokensUsed: tokensUsed,
      estimatedCost: estimatedCost,
      confidence: 0.93,
      enhanced: true,
      realTime: analysis.needsRealTimeData
    };
  }

  /**
   * CONNECTEUR WIKIPEDIA
   */
  async queryWikipedia(query, analysis, context = {}) {
    try {
      // Recherche d'articles
      const searchUrl = `${this.sources.wikipedia.baseUrl}/page/summary/${encodeURIComponent(query)}`;
      
      const response = await fetch(searchUrl);
      if (!response.ok) {
        // Fallback vers recherche textuelle
        return await this.searchWikipedia(query, analysis);
      }

      const data = await response.json();
      
      return {
        content: `📚 **Wikipedia Knowledge**\n\n**${data.title}**\n\n${data.extract}\n\n🔗 Plus d'infos: ${data.content_urls?.desktop?.page || 'Wikipedia'}`,
        source: 'Wikipedia',
        confidence: 0.88,
        enhanced: true,
        verified: true
      };
    } catch (error) {
      logger.warn('Wikipedia query failed:', error.message);
      throw error;
    }
  }

  async searchWikipedia(query, analysis) {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(query)}&srlimit=1&origin=*`;
    
    const response = await fetch(searchUrl);
    const data = await response.json();
    
    if (data.query?.search?.length > 0) {
      const article = data.query.search[0];
      return {
        content: `📚 **Wikipedia Search**\n\n**${article.title}**\n\n${article.snippet.replace(/<[^>]*>/g, '')}\n\n🔗 Recherche Wikipedia pour plus de détails`,
        source: 'Wikipedia Search',
        confidence: 0.85,
        enhanced: true
      };
    }
    
    throw new Error('No Wikipedia results found');
  }

  /**
   * CONNECTEURS APIS SPÉCIALISÉES
   */
  async queryWeatherAPI(query, analysis, context = {}) {
    // Placeholder pour API météo réelle
    const location = analysis.entities.locations[0] || 'global';
    
    return {
      content: `🌤️ **Données météo temps réel** pour ${location}\n\nConnexion à l'API météo en cours...\n\n*Note: Configuration API météo requise pour données live*`,
      source: 'Weather API (Demo)',
      confidence: 0.7,
      realTime: true
    };
  }

  async queryNewsAPI(query, analysis, context = {}) {
    return {
      content: `📰 **Actualités temps réel**\n\nRecherche d'actualités en cours...\n\n*Note: Configuration News API requise pour données live*`,
      source: 'News API (Demo)',
      confidence: 0.7,
      realTime: true
    };
  }

  async queryFinanceAPI(query, analysis, context = {}) {
    return {
      content: `💹 **Données financières temps réel**\n\nConsultation des marchés...\n\n*Note: Configuration Finance API requise pour données live*`,
      source: 'Finance API (Demo)',
      confidence: 0.7,
      realTime: true
    };
  }

  /**
   * FONCTIONS UTILITAIRES
   */
  buildSystemPrompt(analysis) {
    return `Tu es Alex Ultimate, une IA avancée multilingue. 
Contexte de la requête: ${JSON.stringify(analysis)}
Réponds dans la langue détectée: ${analysis.language}
Sois précis, informatif et adapte ton style au contexte.`;
  }

  buildContextualMessages(query, context, systemPrompt) {
    const messages = [{ role: 'system', content: systemPrompt }];
    
    // Ajouter le contexte de conversation s'il existe
    if (context.conversation && context.conversation.length > 0) {
      context.conversation.slice(-6).forEach(msg => {
        messages.push({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: msg.content
        });
      });
    }
    
    messages.push({ role: 'user', content: query });
    return messages;
  }

  buildAnthropicMessages(query, context) {
    const messages = [];
    
    if (context.conversation && context.conversation.length > 0) {
      context.conversation.slice(-6).forEach(msg => {
        messages.push({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: msg.content
        });
      });
    }
    
    messages.push({ role: 'user', content: query });
    return messages;
  }

  generateCacheKey(query, analysis) {
    return `${query}_${analysis.type}_${analysis.language}_${Date.now() - (Date.now() % 300000)}`; // Cache 5min
  }

  cacheResponse(key, response) {
    // Cache avec TTL de 5 minutes pour données dynamiques
    if (this.cache.size > 100) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    
    this.cache.set(key, {
      ...response,
      cachedAt: Date.now()
    });
  }

  async queryLocalAlex(query, analysis, context) {
    // Fallback vers le système local d'Alex
    return {
      content: `🤖 **Alex Ultimate Local Analysis**\n\nAnalyse locale de votre requête: "${query}"\n\nType: ${analysis.type}\nComplexité: ${analysis.complexity}\nLangue: ${analysis.language}\n\nRéponse générée par les 154 modules locaux d'Alex.`,
      source: 'Alex Local Intelligence',
      confidence: 0.8,
      local: true
    };
  }

  generateFallbackResponse(query, analysis) {
    return {
      content: `🛠️ **Mode dégradé Alex Ultimate**\n\nJe traite votre demande "${query}" avec mes systèmes de sauvegarde.\n\nToutes les connexions externes seront rétablies sous peu.`,
      source: 'Alex Fallback',
      confidence: 0.6,
      fallback: true
    };
  }
}

export default new ExternalDataSources();