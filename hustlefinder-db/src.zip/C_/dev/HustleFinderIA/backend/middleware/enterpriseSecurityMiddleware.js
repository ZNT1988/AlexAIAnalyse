/**
 * @fileoverview Enterprise Security Middleware - Advanced Security Layer
 * Comprehensive security middleware with OAuth2, encryption, and monitoring
 * 
 * @module EnterpriseSecurityMiddleware
 * @version 1.0.0
 * @author HustleFinder IA Team - Security Implementation
 */

import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import slowDown from 'express-slow-down';
import { getSecurityManager } from '../security/EnterpriseSecurityManager.js';
import logger from '../config/logger.js';

/**
 * Create comprehensive security middleware stack
 */
export function createEnterpriseSecurityMiddleware() {
    const securityManager = getSecurityManager();
    
    return [
        // 1. Advanced Helmet configuration for enterprise security
        helmet({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
                    fontSrc: ["'self'", "https://fonts.gstatic.com"],
                    imgSrc: ["'self'", "data:", "https:"],
                    scriptSrc: ["'self'"],
                    objectSrc: ["'none'"],
                    upgradeInsecureRequests: []
                }
            },
            hsts: {
                maxAge: 31536000, // 1 year
                includeSubDomains: true,
                preload: true
            },
            noSniff: true,
            frameguard: { action: 'deny' },
            xssFilter: true,
            referrerPolicy: { policy: 'same-origin' }
        }),

        // 2. Advanced rate limiting with intelligent detection
        createIntelligentRateLimit(),

        // 3. DDoS protection with slow-down
        createDDoSProtection(),

        // 4. Request sanitization and validation
        createRequestSanitizer(),

        // 5. Security headers middleware
        createSecurityHeaders(),

        // 6. IP filtering and geoblocking (if configured)
        createIPFilter(),

        // 7. Request fingerprinting for anomaly detection
        createRequestFingerprinting()
    ];
}

/**
 * Create intelligent rate limiting based on user behavior
 */
function createIntelligentRateLimit() {
    return rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: (req) => {
            // Higher limits for authenticated users
            if (req.user) {
                return req.user.tier === 'premium' ? 1000 : 500;
            }
            return 100; // Anonymous users
        },
        message: {
            error: 'Too many requests from this IP',
            retryAfter: '15 minutes',
            type: 'rate_limit_exceeded'
        },
        standardHeaders: true,
        legacyHeaders: false,
        handler: (req, res) => {
            const securityManager = getSecurityManager();
            securityManager.auditLog('rate_limit_exceeded', {
                ip: req.ip,
                userAgent: req.get('User-Agent'),
                path: req.path
            }, 'warning');

            res.status(429).json({
                success: false,
                error: 'Rate limit exceeded',
                retryAfter: Math.round(req.rateLimit.resetTime / 1000)
            });
        },
        // Skip rate limiting for health checks and static assets
        skip: (req) => {
            return req.path.startsWith('/health') || 
                   req.path.startsWith('/api/health') ||
                   req.path.startsWith('/static/');
        }
    });
}

/**
 * Create DDoS protection with progressive delays
 */
function createDDoSProtection() {
    return slowDown({
        windowMs: 15 * 60 * 1000, // 15 minutes
        delayAfter: 50, // Allow 50 requests per windowMs without delay
        delayMs: 100, // Add 100ms delay per request after delayAfter
        maxDelayMs: 5000, // Maximum delay of 5 seconds
        skipFailedRequests: true,
        skipSuccessfulRequests: false,
        onLimitReached: (req, res, options) => {
            const securityManager = getSecurityManager();
            securityManager.auditLog('ddos_protection_triggered', {
                ip: req.ip,
                userAgent: req.get('User-Agent'),
                path: req.path,
                delayMs: options.delay
            }, 'warning');
        }
    });
}

/**
 * Create request sanitization middleware
 */
function createRequestSanitizer() {
    return (req, res, next) => {
        try {
            // Sanitize query parameters
            if (req.query) {
                req.query = sanitizeObject(req.query);
            }

            // Sanitize request body
            if (req.body) {
                req.body = sanitizeObject(req.body);
            }

            // Validate Content-Type for POST/PUT requests
            if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
                const contentType = req.get('Content-Type');
                if (!contentType || !contentType.includes('application/json')) {
                    if (!req.path.includes('/upload')) { // Allow file uploads
                        return res.status(400).json({
                            success: false,
                            error: 'Invalid Content-Type. Expected application/json'
                        });
                    }
                }
            }

            next();

        } catch (error) {
            logger.error('Request sanitization error:', error);
            res.status(400).json({
                success: false,
                error: 'Invalid request format'
            });
        }
    };
}

/**
 * Sanitize object to prevent XSS and injection attacks
 */
function sanitizeObject(obj) {
    if (typeof obj !== 'object' || obj === null) {
        return sanitizeString(obj);
    }

    if (Array.isArray(obj)) {
        return obj.map(item => sanitizeObject(item));
    }

    const sanitized = {};
    for (const [key, value] of Object.entries(obj)) {
        // Sanitize key
        const cleanKey = sanitizeString(key);
        if (cleanKey !== key) {
            continue; // Skip potentially malicious keys
        }

        sanitized[cleanKey] = sanitizeObject(value);
    }

    return sanitized;
}

/**
 * Sanitize string to prevent XSS
 */
function sanitizeString(str) {
    if (typeof str !== 'string') {
        return str;
    }

    // Remove potentially dangerous patterns
    return str
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
        .replace(/javascript:/gi, '')
        .replace(/on\w+\s*=/gi, '');
}

/**
 * Create security headers middleware
 */
function createSecurityHeaders() {
    return (req, res, next) => {
        // Additional security headers
        res.setHeader('X-Powered-By', 'HustleFinder-IA'); // Custom header
        res.setHeader('X-Request-ID', req.id || generateRequestId());
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('X-Frame-Options', 'DENY');
        res.setHeader('X-XSS-Protection', '1; mode=block');
        res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
        res.setHeader('X-Security-Level', 'enterprise');

        // Remove sensitive headers
        res.removeHeader('X-Powered-By');
        res.removeHeader('Server');

        next();
    };
}

/**
 * Create IP filtering middleware
 */
function createIPFilter() {
    // Load IP whitelist/blacklist from environment or config
    const blacklistedIPs = process.env.IP_BLACKLIST ? 
        process.env.IP_BLACKLIST.split(',').map(ip => ip.trim()) : [];
    const whitelistedIPs = process.env.IP_WHITELIST ? 
        process.env.IP_WHITELIST.split(',').map(ip => ip.trim()) : [];

    return (req, res, next) => {
        const clientIP = getClientIP(req);
        const securityManager = getSecurityManager();

        // Check blacklist first
        if (blacklistedIPs.length > 0 && blacklistedIPs.includes(clientIP)) {
            securityManager.auditLog('ip_blocked_blacklist', {
                ip: clientIP,
                userAgent: req.get('User-Agent'),
                path: req.path
            }, 'warning');

            return res.status(403).json({
                success: false,
                error: 'Access denied'
            });
        }

        // Check whitelist if configured
        if (whitelistedIPs.length > 0 && !whitelistedIPs.includes(clientIP)) {
            securityManager.auditLog('ip_blocked_not_whitelisted', {
                ip: clientIP,
                userAgent: req.get('User-Agent'),
                path: req.path
            }, 'warning');

            return res.status(403).json({
                success: false,
                error: 'Access denied'
            });
        }

        req.clientIP = clientIP;
        next();
    };
}

/**
 * Create request fingerprinting for anomaly detection
 */
function createRequestFingerprinting() {
    return (req, res, next) => {
        const fingerprint = generateRequestFingerprint(req);
        req.fingerprint = fingerprint;

        // Store fingerprint for analysis (could be used for bot detection)
        const securityManager = getSecurityManager();
        securityManager.auditLog('request_fingerprinted', {
            fingerprint: fingerprint.hash,
            ip: req.clientIP || req.ip,
            path: req.path,
            method: req.method
        });

        next();
    };
}

/**
 * JWT Authentication middleware with enterprise features
 */
export function createJWTAuthMiddleware(options = {}) {
    const { optional = false, skipPaths = [] } = options;
    
    return async (req, res, next) => {
        try {
            // Skip authentication for certain paths
            if (skipPaths.some(path => req.path.startsWith(path))) {
                return next();
            }

            const token = extractToken(req);
            
            if (!token) {
                if (optional) {
                    return next();
                }
                
                return res.status(401).json({
                    success: false,
                    error: 'Authentication token required',
                    code: 'TOKEN_MISSING'
                });
            }

            const securityManager = getSecurityManager();
            const decoded = await securityManager.verifyJWT(token);
            
            // Attach user information to request
            req.user = {
                id: decoded.userId,
                sessionId: decoded.sessionId,
                permissions: decoded.permissions || [],
                tier: decoded.tier || 'basic'
            };

            // Check session validity
            if (decoded.sessionId) {
                const session = securityManager.activeSessions.get(decoded.sessionId);
                if (!session || !session.active) {
                    return res.status(401).json({
                        success: false,
                        error: 'Session expired',
                        code: 'SESSION_EXPIRED'
                    });
                }
            }

            next();

        } catch (error) {
            logger.error('JWT authentication error:', error);
            
            let errorCode = 'TOKEN_INVALID';
            let statusCode = 401;

            if (error.name === 'TokenExpiredError') {
                errorCode = 'TOKEN_EXPIRED';
            } else if (error.name === 'JsonWebTokenError') {
                errorCode = 'TOKEN_MALFORMED';
                statusCode = 400;
            }

            res.status(statusCode).json({
                success: false,
                error: error.message,
                code: errorCode
            });
        }
    };
}

/**
 * OAuth2 authentication middleware
 */
export function createOAuth2Middleware() {
    return (req, res, next) => {
        // OAuth2 implementation would go here
        // For now, pass through to existing auth
        next();
    };
}

/**
 * Permission-based authorization middleware
 */
export function createPermissionMiddleware(requiredPermissions = []) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        const userPermissions = req.user.permissions || [];
        const hasPermission = requiredPermissions.every(permission => 
            userPermissions.includes(permission) || userPermissions.includes('admin')
        );

        if (!hasPermission) {
            const securityManager = getSecurityManager();
            securityManager.auditLog('permission_denied', {
                userId: req.user.id,
                requiredPermissions,
                userPermissions,
                path: req.path
            }, 'warning');

            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions',
                required: requiredPermissions
            });
        }

        next();
    };
}

/**
 * Utility functions
 */

function generateRequestId() {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
}

function getClientIP(req) {
    return req.headers['cf-connecting-ip'] || // Cloudflare
           req.headers['x-real-ip'] || // Nginx
           req.headers['x-forwarded-for']?.split(',')[0] || // Standard proxy
           req.connection.remoteAddress ||
           req.socket.remoteAddress ||
           req.ip;
}

function extractToken(req) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        return authHeader.substring(7);
    }
    
    // Also check for token in query parameter (less secure, but sometimes needed)
    return req.query.token || req.cookies?.token;
}

function generateRequestFingerprint(req) {
    const components = [
        req.get('User-Agent') || '',
        req.get('Accept-Language') || '',
        req.get('Accept-Encoding') || '',
        req.headers['x-forwarded-for'] || req.ip || '',
        req.get('Referer') || ''
    ];

    const fingerprint = components.join('|');
    const crypto = require('crypto');
    const hash = crypto.createHash('sha256').update(fingerprint).digest('hex');

    return {
        hash,
        components: {
            userAgent: req.get('User-Agent'),
            acceptLanguage: req.get('Accept-Language'),
            acceptEncoding: req.get('Accept-Encoding'),
            ip: req.headers['x-forwarded-for'] || req.ip,
            referer: req.get('Referer')
        }
    };
}

export default {
    createEnterpriseSecurityMiddleware,
    createJWTAuthMiddleware,
    createOAuth2Middleware,
    createPermissionMiddleware
};