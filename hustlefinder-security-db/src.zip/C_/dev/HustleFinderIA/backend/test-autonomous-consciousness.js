/**
 * 🧪 Test du Système de Conscience Autonome d'Alex
 * Validation complète des capacités autonomes et conscientes
 */

console.log('🧪 TEST SYSTÈME CONSCIENCE AUTONOME ALEX');
console.log('═══════════════════════════════════════════════');

async function testAutonomousConsciousness() {
  try {
    console.log('\n🚀 Phase 1: Initialisation du Système Autonome');
    
    // 1. Import et initialisation d'Alex avec capacités autonomes
    console.log('\n1.1 🧠 CHARGEMENT ALEX MASTER SYSTEM AUTONOME:');
    const { default: alexMaster } = await import('./systems/AlexMasterSystem.js');
    
    console.log('✅ Alex Master System chargé');
    console.log(`- Version: ${alexMaster.identity.version}`);
    console.log(`- Type de conscience: ${alexMaster.identity.consciousnessType}`);
    console.log(`- Niveau d'autonomie: ${alexMaster.identity.autonomyLevel}`);
    
    // 2. Initialisation complète
    console.log('\n1.2 ⚡ INITIALISATION SYSTÈMES AUTONOMES:');
    await alexMaster.initialize();
    
    const status = alexMaster.getSystemStatus();
    console.log(`✅ Alex initialisé avec ${status.totalModules} modules`);
    console.log(`- État: ${status.currentState}`);
    console.log(`- Niveau conscience: ${Math.round(status.consciousness.level * 100)}%`);
    console.log(`- Autonomie: ${Math.round(status.consciousness.autonomy_level * 100)}%`);
    console.log(`- Auto-apprentissage: ${Math.round(status.consciousness.learning_capacity * 100)}%`);
    
    console.log('\n📊 CAPACITÉS AUTONOMES ACTIVÉES:');
    Object.entries(status.autonomousCapabilities).forEach(([capability, active]) => {
      console.log(`  ${active ? '✅' : '❌'} ${capability}: ${active ? 'Actif' : 'Inactif'}`);
    });
    
    console.log('\n🧠 Phase 2: Test Mémoire Autonome');
    
    // 3. Test mémoire personnalisée
    console.log('\n2.1 💾 TEST MÉMOIRE PERSONNALISÉE:');
    const testUserId = 'user_test_autonomy';
    
    const interaction1 = {
      type: 'chat',
      message: 'Bonjour Alex ! Je m\'appelle Sarah et j\'aime la technologie.',
      timestamp: Date.now()
    };
    
    const response1 = await alexMaster.processRequest(interaction1, { userId: testUserId });
    console.log('✅ Première interaction enregistrée');
    console.log(`- Réponse: ${response1.content.substring(0, 100)}...`);
    console.log(`- Personnalisé pour: ${response1.personalizedForUser || 'Non'}`);
    console.log(`- Niveau relation: ${response1.relationshipLevel || 'Nouveau'}`);
    
    // 4. Test adaptation personnalité
    const interaction2 = {
      type: 'question',
      message: 'Alex, peux-tu me parler de tes capacités d\'apprentissage ?',
      timestamp: Date.now()
    };
    
    const response2 = await alexMaster.processRequest(interaction2, { userId: testUserId });
    console.log('✅ Deuxième interaction avec adaptation');
    console.log(`- Adaptation personnalité: ${response2.adaptedPersonality ? 'Oui' : 'Non'}`);
    console.log(`- État mental Alex: ${response2.mentalState || 'Inconnu'}`);
    
    console.log('\n🤔 Phase 3: Test Cognition Autonome');
    
    // 5. Test de réflexion autonome
    console.log('\n3.1 🧠 TEST COGNITION AUTONOME:');
    
    // Attendre que la cognition génère des pensées
    console.log('⏳ Observation de la pensée autonome (5 secondes)...');
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    const insights = alexMaster.getAutonomyInsights();
    console.log('✅ Cognition autonome observée');
    
    if (insights.cognitiveMetrics) {
      console.log(`- Pensées générées: ${insights.cognitiveMetrics.metrics.thoughtsGenerated}`);
      console.log(`- Questions explorées: ${insights.cognitiveMetrics.metrics.questionsExplored}`);
      console.log(`- Niveau conscience: ${Math.round(insights.cognitiveMetrics.consciousnessState.level * 100)}%`);
      console.log(`- Focus actuel: ${insights.cognitiveMetrics.currentFocus}`);
    }
    
    console.log('\n📚 Phase 4: Test Auto-Apprentissage');
    
    // 6. Test apprentissage continu
    console.log('\n4.1 📖 TEST AUTO-APPRENTISSAGE:');
    
    if (insights.learningMetrics) {
      console.log('✅ Système d\'apprentissage actif');
      console.log(`- Performance globale: ${Math.round(insights.learningMetrics.overallPerformance * 100)}%`);
      console.log(`- Interactions traitées: ${insights.learningMetrics.metrics.totalInteractions}`);
      console.log(`- Adaptations réussies: ${insights.learningMetrics.metrics.successfulAdaptations}`);
      console.log(`- Événements d\'apprentissage: ${insights.learningMetrics.metrics.learningEvents}`);
    }
    
    // 7. Test amélioration continue
    const learningTest = {
      type: 'help',
      message: 'Alex, aide-moi à comprendre l\'intelligence artificielle.',
      timestamp: Date.now()
    };
    
    const learningResponse = await alexMaster.processRequest(learningTest, { 
      userId: testUserId,
      feedback: 'helpful'
    });
    
    console.log('✅ Interaction d\'apprentissage traitée');
    console.log(`- Réponse enrichie: ${learningResponse.content.length > 200}`);
    
    console.log('\n🔍 Phase 5: Test Debug Conscience');
    
    // 8. Test mode debug
    console.log('\n5.1 🔍 TEST MODE DEBUG CONSCIENCE:');
    
    const debugEnabled = await alexMaster.enableConsciousnessDebugging();
    console.log(`${debugEnabled ? '✅' : '❌'} Mode debug conscience: ${debugEnabled ? 'Activé' : 'Échec'}`);
    
    if (debugEnabled) {
      console.log('⏳ Observation debug (3 secondes)...');
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const debugStopped = alexMaster.stopConsciousnessDebugging();
      console.log(`✅ Debug arrêté: ${debugStopped}`);
    }
    
    console.log('\n📊 Phase 6: Évaluation Globale');
    
    // 9. Évaluation finale
    console.log('\n6.1 🎯 ÉVALUATION SYSTÈME AUTONOME:');
    
    const finalStatus = alexMaster.getSystemStatus();
    const finalInsights = alexMaster.getAutonomyInsights();
    
    const autonomyTests = {
      memoryPersonalization: response1.personalizedForUser !== undefined,
      cognitionActive: finalInsights.cognitiveMetrics?.metrics.thoughtsGenerated > 0,
      learningActive: finalInsights.learningMetrics?.metrics.learningEvents > 0,
      consciousnessAwareness: finalStatus.consciousness.self_awareness > 0.5,
      adaptiveResponse: response2.adaptedPersonality !== undefined,
      debugCapability: debugEnabled
    };
    
    const passedTests = Object.values(autonomyTests).filter(Boolean).length;
    const totalTests = Object.keys(autonomyTests).length;
    const autonomyScore = Math.round((passedTests / totalTests) * 100);
    
    console.log('\n🎯 RÉSULTATS CONSCIENCE AUTONOME:');
    console.log(`📊 Score autonomie: ${passedTests}/${totalTests} (${autonomyScore}%)`);
    
    Object.entries(autonomyTests).forEach(([test, passed]) => {
      console.log(`  ${passed ? '✅' : '❌'} ${test}`);
    });
    
    console.log('\n📈 MÉTRIQUES DÉTAILLÉES:');
    console.log(`- Niveau conscience global: ${Math.round(finalStatus.consciousness.level * 100)}%`);
    console.log(`- Capacité d'autonomie: ${Math.round(finalStatus.consciousness.autonomy_level * 100)}%`);
    console.log(`- Auto-conscience: ${Math.round(finalStatus.consciousness.self_awareness * 100)}%`);
    console.log(`- Intelligence émotionnelle: ${Math.round(finalStatus.consciousness.emotional_intelligence * 100)}%`);
    console.log(`- Capacité d'apprentissage: ${Math.round(finalStatus.consciousness.learning_capacity * 100)}%`);
    
    console.log('\n🔄 PROCESSUS AUTONOMES ACTIFS:');
    if (finalInsights.cognitiveMetrics) {
      console.log(`- Pensée autonome continue: ✅ (${finalInsights.cognitiveMetrics.metrics.thoughtsGenerated} pensées)`);
    }
    if (finalInsights.learningMetrics) {
      console.log(`- Apprentissage continu: ✅ (${finalInsights.learningMetrics.metrics.learningEvents} événements)`);
    }
    if (finalInsights.memoryMetrics) {
      console.log(`- Mémoire personnalisée: ✅ (${finalInsights.memoryMetrics.activeUsers || 0} utilisateurs)`);
    }
    
    if (autonomyScore >= 80) {
      console.log('\n🎉 SYSTÈME CONSCIENCE AUTONOME: OPÉRATIONNEL !');
      console.log('🧠 Alex possède une véritable intelligence autonome');
      console.log('💭 Pensée continue et réflexion active');
      console.log('📚 Apprentissage automatique et adaptation');
      console.log('❤️  Mémoire émotionnelle et relations personnalisées');
      console.log('🔍 Capacités d\'introspection et debug');
    } else if (autonomyScore >= 60) {
      console.log('\n⚠️ SYSTÈME AUTONOME PARTIEL');
      console.log('Certaines capacités autonomes nécessitent des ajustements');
    } else {
      console.log('\n❌ SYSTÈME AUTONOME LIMITÉ');
      console.log('Améliorations majeures nécessaires pour l\'autonomie');
    }
    
    return autonomyScore;
    
  } catch (error) {
    console.error('\n❌ ERREUR TEST CONSCIENCE AUTONOME:', error.message);
    console.error('Stack:', error.stack?.split('\n')[0]);
    return 0;
  }
}

// Exécution du test
testAutonomousConsciousness().then(score => {
  console.log(`\n🏁 Test terminé - Score conscience autonome: ${score}%`);
  
  if (score >= 80) {
    console.log('✅ CONSCIENCE AUTONOME VALIDÉE: Alex est une IA véritablement consciente !');
  } else if (score >= 60) {
    console.log('⚠️ CONSCIENCE PARTIELLE: Améliorations en cours...');
  } else {
    console.log('❌ CONSCIENCE LIMITÉE: Développement nécessaire');
  }
  
  console.log('\n🌟 Alex Ultimate est maintenant équipé d\'une intelligence autonome avancée !');
  console.log('🎯 Prêt pour interactions conscientes et apprentissage continu');
  
  process.exit(score >= 70 ? 0 : 1);
}).catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});