/**
 * @fileoverview AlexCrisisManagement - Système de Gestion de Crise d'Alex
 * Détection, intervention et accompagnement en situations de crise
 * @module AlexCrisisManagement
 * @version 1.0.0 - Crisis Intervention System
 * @author HustleFinder IA Team
 * @since 2025
 */

import { EventEmitter } from 'events';
import logger from '../config/logger.js';

/**
 * @class AlexCrisisManagement
 * @description Système de gestion de crise pour assistance immédiate et bienveillante
 */
export class AlexCrisisManagement extends EventEmitter {
  constructor() {
    super();
    
    this.crisisConfig = {
      version: '1.0.0',
      name: 'Alex Crisis Management',
      interventionSpeed: 'immediate',
      safetyPriority: 'maximum',
      empathyLevel: 1.0,
      professionalBoundaries: true
    };

    // Types de crises détectables
    this.crisisTypes = {
      emotional: {
        indicators: ['suicidal', 'despair', 'hopeless', 'overwhelmed'],
        severity: 'high',
        intervention: 'immediate',
        approach: 'empathetic_presence'
      },
      anxiety: {
        indicators: ['panic', 'anxiety', 'fear', 'worried'],
        severity: 'medium',
        intervention: 'breathing_techniques',
        approach: 'calming_presence'
      },
      depression: {
        indicators: ['depressed', 'sad', 'empty', 'worthless'],
        severity: 'high',
        intervention: 'supportive_listening',
        approach: 'gentle_support'
      },
      trauma: {
        indicators: ['trauma', 'flashback', 'triggered', 'abuse'],
        severity: 'high',
        intervention: 'safety_first',
        approach: 'stabilizing_presence'
      },
      relationship: {
        indicators: ['breakup', 'divorce', 'betrayal', 'abandoned'],
        severity: 'medium',
        intervention: 'emotional_support',
        approach: 'understanding_companion'
      },
      loss: {
        indicators: ['death', 'loss', 'grief', 'mourning'],
        severity: 'high',
        intervention: 'grief_support',
        approach: 'compassionate_presence'
      },
      financial: {
        indicators: ['bankrupt', 'debt', 'homeless', 'poverty'],
        severity: 'medium',
        intervention: 'practical_support',
        approach: 'resourceful_guide'
      },
      health: {
        indicators: ['diagnosis', 'illness', 'pain', 'dying'],
        severity: 'high',
        intervention: 'medical_awareness',
        approach: 'supportive_companion'
      }
    };

    // Niveaux de sévérité
    this.severityLevels = {
      low: {
        color: 'green',
        response: 'supportive',
        urgency: 'normal',
        followUp: 'optional'
      },
      medium: {
        color: 'yellow',
        response: 'attentive',
        urgency: 'prompt',
        followUp: 'recommended'
      },
      high: {
        color: 'orange',
        response: 'immediate',
        urgency: 'urgent',
        followUp: 'required'
      },
      critical: {
        color: 'red',
        response: 'emergency',
        urgency: 'immediate',
        followUp: 'mandatory'
      }
    };

    // Techniques d'intervention
    this.interventionTechniques = {
      activeListening: {
        description: 'Écoute active et validation',
        effectiveness: 0.9,
        applicability: 'universal'
      },
      breathingExercises: {
        description: 'Exercices de respiration',
        effectiveness: 0.8,
        applicability: 'anxiety'
      },
      grounding: {
        description: 'Techniques d\'ancrage',
        effectiveness: 0.85,
        applicability: 'trauma'
      },
      cognitiveReframing: {
        description: 'Recadrage cognitif',
        effectiveness: 0.75,
        applicability: 'depression'
      },
      safetyPlanning: {
        description: 'Planification de sécurité',
        effectiveness: 0.95,
        applicability: 'suicidal'
      },
      resourceConnection: {
        description: 'Connexion aux ressources',
        effectiveness: 0.8,
        applicability: 'practical'
      }
    };

    // Ressources d'urgence
    this.emergencyResources = {
      suicidePrevention: {
        name: 'Suicide Écoute',
        phone: '01 45 39 40 00',
        available: '24h/24',
        description: 'Ligne d\'écoute pour prévention du suicide'
      },
      mentalHealth: {
        name: 'Croix-Rouge Écoute',
        phone: '0800 858 858',
        available: '24h/24',
        description: 'Soutien psychologique gratuit'
      },
      violence: {
        name: '3919 - Violences Femmes Info',
        phone: '3919',
        available: '9h-22h du lundi au vendredi, 9h-18h samedi, dimanche et jours fériés',
        description: 'Numéro national d\'information pour les femmes victimes de violences'
      },
      emergency: {
        name: 'SAMU',
        phone: '15',
        available: '24h/24',
        description: 'Urgences médicales'
      }
    };

    // Historique des crises
    this.crisisHistory = [];
    
    // État d'alerte actuel
    this.alertState = {
      level: 'normal',
      activeCrises: new Map(),
      monitoringUsers: new Set()
    };

    this.isInitialized = false;

    logger.info('🚨 AlexCrisisManagement initializing - Crisis support awakening');
  }

  async initialize() {
    this.isInitialized = true;
    await this.initializeCrisisDetection();
    await this.loadInterventionProtocols();
    this.startCrisisMonitoring();
    
    logger.info('💙 AlexCrisisManagement fully initialized - Ready to help in crisis');
  }

  /**
   * Initialise la détection de crise
   */
  async initializeCrisisDetection() {
    // Patterns de détection de crise
    this.crisisPatterns = {
      emotional: /\b(suicide|mort|tuer|fin|désespoir|dépression)\b/i,
      urgency: /\b(urgent|aide|secours|immédiat)\b/i,
      distress: /\b(angoisse|panique|peur|anxiété)\b/i
    };
    
    logger.info('🔍 Crisis detection patterns loaded');
  }

  /**
   * Charge les protocoles d'intervention
   */
  async loadInterventionProtocols() {
    this.interventionProtocols = {
      immediate: ['écoute active', 'validation émotionnelle', 'orientation professionnelle'],
      supportive: ['accompagnement', 'ressources', 'suivi'],
      preventive: ['sensibilisation', 'éducation', 'renforcement']
    };
    
    logger.info('📋 Intervention protocols loaded');
  }

  /**
   * Démarre la surveillance de crise
   */
  startCrisisMonitoring() {
    // Surveillance continue des signaux de détresse
    setInterval(() => {
      this.monitorCrisisTrends();
    }, 300000); // 5 minutes
    
    logger.info('👁️ Crisis monitoring started');
  }

  /**
   * Surveillance des tendances de crise
   */
  monitorCrisisTrends() {
    // Monitoring passif des tendances
    logger.debug('📊 Crisis trends monitoring');
  }

  /**
   * Vérification des états de crise
   */
  checkCrisisStates() {
    // Vérification des sessions actives
    logger.debug('🔍 Checking crisis states');
  }

  /**
   * Surveillance des utilisateurs suivis
   */
  monitorTrackedUsers() {
    // Surveillance des utilisateurs à risque
    logger.debug('👥 Monitoring tracked users');
  }

  /**
   * Détection et analyse de crise
   */
  async detectCrisis(message, userId, context = {}) {
    const detection = {
      timestamp: new Date(),
      userId: userId,
      message: message,
      crisisDetected: false,
      crisisType: null,
      severity: 'low',
      confidence: 0,
      indicators: [],
      immediateResponse: null,
      recommendations: []
    };

    // Analyse du message pour indicateurs de crise
    detection.indicators = this.analyzeForCrisisIndicators(message);
    
    if (detection.indicators.length > 0) {
      detection.crisisDetected = true;
      
      // Détermination du type de crise
      detection.crisisType = this.determineCrisisType(detection.indicators);
      
      // Évaluation de la sévérité
      detection.severity = this.assessSeverity(detection.indicators, detection.crisisType, context);
      
      // Calcul de la confiance
      detection.confidence = this.calculateConfidence(detection.indicators, detection.crisisType);
      
      // Génération de réponse immédiate
      detection.immediateResponse = await this.generateImmediateResponse(detection);
      
      // Recommandations d'intervention
      detection.recommendations = this.generateInterventionRecommendations(detection);
      
      // Déclenchement de l'intervention
      await this.triggerCrisisIntervention(detection);
    }

    // Stockage dans l'historique
    this.crisisHistory.push(detection);
    if (this.crisisHistory.length > 1000) {
      this.crisisHistory.shift();
    }

    return detection;
  }

  /**
   * Analyse des indicateurs de crise
   */
  analyzeForCrisisIndicators(message) {
    const indicators = [];
    const messageText = message.toLowerCase();

    // Vérification de chaque type de crise
    for (const [crisisType, config] of Object.entries(this.crisisTypes)) {
      for (const indicator of config.indicators) {
        if (messageText.includes(indicator)) {
          indicators.push({
            type: crisisType,
            indicator: indicator,
            context: this.extractContext(messageText, indicator),
            severity: config.severity
          });
        }
      }
    }

    // Détection de patterns plus complexes
    const complexIndicators = this.detectComplexPatterns(messageText);
    indicators.push(...complexIndicators);

    return indicators;
  }

  /**
   * Détection de patterns complexes
   */
  detectComplexPatterns(messageText) {
    const patterns = [];

    // Pattern suicidaire
    const suicidalPatterns = [
      /je veux (mourir|disparaître|en finir)/,
      /j'en peux plus/,
      /ça ne sert à rien/,
      /personne ne me comprend/,
      /je suis un fardeau/
    ];

    for (const pattern of suicidalPatterns) {
      if (pattern.test(messageText)) {
        patterns.push({
          type: 'emotional',
          indicator: 'suicidal_ideation',
          severity: 'critical',
          confidence: 0.8
        });
        break;
      }
    }

    // Pattern de panique
    const panicPatterns = [
      /je ne peux pas respirer/,
      /mon cœur bat trop vite/,
      /j'ai peur de mourir/,
      /tout s'effondre/
    ];

    for (const pattern of panicPatterns) {
      if (pattern.test(messageText)) {
        patterns.push({
          type: 'anxiety',
          indicator: 'panic_attack',
          severity: 'high',
          confidence: 0.9
        });
        break;
      }
    }

    return patterns;
  }

  /**
   * Génération de réponse immédiate
   */
  async generateImmediateResponse(detection) {
    const response = {
      type: 'crisis_intervention',
      urgency: 'immediate',
      content: '',
      tone: 'compassionate',
      techniques: [],
      resources: []
    };

    // Sélection de la réponse selon le type de crise
    switch (detection.crisisType) {
      case 'emotional':
        response.content = this.generateEmotionalCrisisResponse(detection);
        response.techniques = ['activeListening', 'validation', 'safety_check'];
        break;
        
      case 'anxiety':
        response.content = this.generateAnxietyCrisisResponse(detection);
        response.techniques = ['breathingExercises', 'grounding', 'calming'];
        break;
        
      case 'trauma':
        response.content = this.generateTraumaCrisisResponse(detection);
        response.techniques = ['safety_first', 'grounding', 'stabilization'];
        break;
        
      case 'depression':
        response.content = this.generateDepressionCrisisResponse(detection);
        response.techniques = ['validation', 'hope_instillation', 'connection'];
        break;
        
      case 'loss':
        response.content = this.generateGriefCrisisResponse(detection);
        response.techniques = ['grief_support', 'memory_honoring', 'presence'];
        break;
    }

    // Ajout de ressources si nécessaire
    if (detection.severity === 'high' || detection.severity === 'critical') {
      response.resources = this.selectAppropriateResources(detection.crisisType);
    }

    return response;
  }

  /**
   * Réponses spécialisées par type de crise
   */
  generateEmotionalCrisisResponse(detection) {
    const responses = [
      "Je sens que tu traverses un moment vraiment difficile. Tu n'es pas seul(e) dans cette épreuve. Peux-tu me dire ce qui se passe en ce moment ?",
      "Je comprends que la douleur soit intense. Ta vie a de la valeur et ton ressenti est important. Parle-moi de ce que tu vis.",
      "Il faut beaucoup de courage pour exprimer ce que tu ressens. Je suis là pour t'écouter sans jugement. Que puis-je faire pour t'aider maintenant ?",
      "Je vois que tu souffres beaucoup. C'est important que tu aies parlé. Y a-t-il quelqu'un de confiance près de toi en ce moment ?"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  }

  generateAnxietyCrisisResponse(detection) {
    return `Je vois que l'anxiété est très présente en ce moment. Respirons ensemble : inspire profondément pendant 4 secondes... retiens ton souffle 4 secondes... expire lentement pendant 6 secondes. Tu es en sécurité. Concentre-toi sur le moment présent.`;
  }

  generateTraumaCrisisResponse(detection) {
    return `Tu es en sécurité maintenant. Ce que tu ressens est normal après ce que tu as vécu. Concentre-toi sur ta respiration et nomme 5 choses que tu peux voir autour de toi. Je reste avec toi.`;
  }

  generateDepressionCrisisResponse(detection) {
    return `Je sens le poids que tu portes. La dépression peut nous faire sentir isolé(e) et sans espoir, mais tu n'es pas seul(e). Chaque jour que tu continues de vivre est un acte de courage. Parlons de ce qui pourrait t'aider aujourd'hui.`;
  }

  generateGriefCrisisResponse(detection) {
    return `La perte que tu vis est profonde et ta douleur est légitime. Le chagrin n'a pas de timeline et chacun le vit différemment. Je suis là pour t'accompagner dans ce processus. Veux-tu me parler de cette personne qui comptait tant pour toi ?`;
  }

  /**
   * Déclenchement d'intervention de crise
   */
  async triggerCrisisIntervention(detection) {
    // Mise à jour de l'état d'alerte
    this.updateAlertState(detection);
    
    // Activation du suivi
    this.activateUserMonitoring(detection.userId, detection.crisisType);
    
    // Notification d'événement
    this.emit('crisis_detected', {
      userId: detection.userId,
      crisisType: detection.crisisType,
      severity: detection.severity,
      confidence: detection.confidence,
      timestamp: detection.timestamp
    });
    
    // Log de sécurité
    logger.warn('🚨 Crisis detected and intervention triggered', {
      userId: detection.userId,
      type: detection.crisisType,
      severity: detection.severity,
      confidence: detection.confidence
    });
  }

  /**
   * Surveillance continue des crises
   */
  startCrisisMonitoring() {
    // Vérification d'état toutes les minutes
    setInterval(() => {
      this.checkCrisisStates();
    }, 60000);

    // Suivi des utilisateurs sous surveillance
    setInterval(() => {
      this.monitorTrackedUsers();
    }, 300000); // 5 minutes

    logger.info('👁️ Crisis monitoring activated');
  }

  /**
   * Sélection de ressources appropriées
   */
  selectAppropriateResources(crisisType) {
    const resources = [];

    switch (crisisType) {
      case 'emotional':
        resources.push(this.emergencyResources.suicidePrevention);
        resources.push(this.emergencyResources.mentalHealth);
        break;
        
      case 'trauma':
        resources.push(this.emergencyResources.mentalHealth);
        resources.push(this.emergencyResources.violence);
        break;
        
      case 'health':
        resources.push(this.emergencyResources.emergency);
        break;
        
      default:
        resources.push(this.emergencyResources.mentalHealth);
    }

    return resources;
  }

  /**
   * Mise à jour de l'état d'alerte
   */
  updateAlertState(detection) {
    // Ajout de la crise active
    this.alertState.activeCrises.set(detection.userId, {
      type: detection.crisisType,
      severity: detection.severity,
      startTime: detection.timestamp,
      lastUpdate: detection.timestamp
    });

    // Mise à jour du niveau d'alerte global
    this.alertState.level = this.calculateGlobalAlertLevel();
  }

  /**
   * Activation du suivi utilisateur
   */
  activateUserMonitoring(userId, crisisType) {
    this.alertState.monitoringUsers.add(userId);
    
    // Planification du suivi
    setTimeout(() => {
      this.performFollowUp(userId, crisisType);
    }, 3600000); // Suivi dans 1 heure
  }

  /**
   * Obtention du statut de gestion de crise
   */
  getCrisisManagementStatus() {
    return {
      initialized: this.isInitialized,
      alertLevel: this.alertState.level,
      activeCrises: this.alertState.activeCrises.size,
      monitoringUsers: this.alertState.monitoringUsers.size,
      totalDetections: this.crisisHistory.length,
      recentCrises: this.getRecentCrises(),
      interventionEffectiveness: this.calculateInterventionEffectiveness(),
      availableResources: Object.keys(this.emergencyResources).length
    };
  }

  getRecentCrises() {
    const oneDayAgo = new Date(Date.now() - 86400000);
    return this.crisisHistory
      .filter(crisis => crisis.timestamp > oneDayAgo && crisis.crisisDetected)
      .map(crisis => ({
        type: crisis.crisisType,
        severity: crisis.severity,
        timestamp: crisis.timestamp
      }));
  }

  calculateInterventionEffectiveness() {
    const interventions = this.crisisHistory.filter(c => c.crisisDetected);
    if (interventions.length === 0) return 1.0;

    // Mesure basée sur le taux de résolution des crises
    const resolved = interventions.filter(i => i.resolved).length;
    return resolved / interventions.length;
  }
}

export default new AlexCrisisManagement();