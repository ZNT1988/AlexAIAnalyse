/**
 * 🧪 TEST DU SYSTÈME ULTRA-OPTIMISÉ
 * Benchmark des performances après optimisation
 */

console.log('🧪 TEST DU REGISTRE ULTRA-OPTIMISÉ');
console.log('='.repeat(50));

try {
  const alexMaster = await import('./systems/AlexMasterSystem.js');
  
  console.log('⚡ Initialisation avec nouveau registre...');
  const startTime = Date.now();
  await alexMaster.default.initialize();
  const initTime = Date.now() - startTime;
  
  const moduleStatus = alexMaster.default.getModuleStatus();
  
  console.log('📊 RÉSULTATS POST-OPTIMISATION:');
  console.log('- Modules enregistrés:', moduleStatus.registry.systemState.totalRegistered);
  console.log('- Modules chargés:', moduleStatus.registry.systemState.totalLoaded);
  console.log('- Modules échoués:', moduleStatus.registry.systemState.totalFailed);
  console.log('- Ratio de succès:', Math.round((moduleStatus.registry.systemState.totalLoaded / moduleStatus.registry.systemState.totalRegistered) * 100) + '%');
  console.log('- Temps d\'initialisation:', initTime + 'ms');
  
  console.log('\n📋 DÉTAIL PAR CATÉGORIE:');
  const categories = moduleStatus.registry.systemState.categories || {};
  let totalExpected = 0;
  let totalActual = 0;
  
  for(const [catName, catData] of Object.entries(categories)) {
    const loaded = catData.loaded || 0;
    const total = catData.total || 0;
    const failed = catData.failed || 0;
    const ratio = total > 0 ? Math.round((loaded/total)*100) : 0;
    
    totalExpected += total;
    totalActual += loaded;
    
    console.log(`- ${catName}: ${loaded}/${total} (${ratio}%) - ${failed} échecs`);
  }
  
  const improvement = moduleStatus.registry.systemState.totalLoaded - 52;
  const globalRatio = Math.round((totalActual / totalExpected) * 100);
  
  console.log('\n🎯 RÉSUMÉ PERFORMANCE:');
  console.log(`- Amélioration: +${improvement} modules actifs!`);
  console.log(`- Performance globale: ${globalRatio}%`);
  console.log(`- Objectif 90%+: ${globalRatio >= 90 ? '✅ ATTEINT!' : '⚠️ En cours...'}`);
  
  // Test de traitement
  console.log('\n🧠 TEST DE TRAITEMENT:');
  const testStart = Date.now();
  const response = await alexMaster.default.processRequest(
    { type: 'chat', message: 'Test performance optimisée', timestamp: Date.now() },
    { userId: 'perf_test', sessionId: 'optimization_test' }
  );
  const testTime = Date.now() - testStart;
  
  console.log(`- Temps de réponse: ${testTime}ms`);
  console.log(`- Modules utilisés: ${response.metadata?.modulesUsed || 0}`);
  console.log(`- Performance < 200ms: ${testTime < 200 ? '✅ OPTIMAL' : '⚡ Acceptable'}`);
  
  console.log('\n🎉 TEST TERMINÉ AVEC SUCCÈS!');
  
} catch(error) {
  console.log('❌ Erreur système:', error.message);
  console.log('Stack:', error.stack.split('\n').slice(0,3).join('\n'));
}