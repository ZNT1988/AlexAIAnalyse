/**
 * @fileoverview Load Test - Verify Ultra-Fast Performance
 * Tests response times and throughput for <200ms target
 * 
 * @module LoadTest
 * @version 1.0.0
 * @author HustleFinder IA Team - Performance Testing
 */

import http from 'http';
import { performance } from 'perf_hooks';

/**
 * Simple load testing utility
 */
class LoadTester {
    constructor(options = {}) {
        this.host = options.host || 'localhost';
        this.port = options.port || 8080;
        this.concurrent = options.concurrent || 10;
        this.requests = options.requests || 100;
        this.timeout = options.timeout || 5000;
        this.results = [];
    }

    /**
     * Run load test
     */
    async run() {
        console.log('🚀 Starting HustleFinder Performance Load Test');
        console.log(`📊 Target: <200ms response time, ${this.requests} requests, ${this.concurrent} concurrent`);
        console.log(`🎯 Testing: http://${this.host}:${this.port}`);
        console.log('─'.repeat(60));

        const startTime = performance.now();
        const promises = [];

        // Create concurrent request batches
        for (let i = 0; i < this.concurrent; i++) {
            promises.push(this.runBatch(Math.floor(this.requests / this.concurrent)));
        }

        try {
            await Promise.all(promises);
            const totalTime = performance.now() - startTime;
            
            this.analyzeResults(totalTime);
        } catch (error) {
            console.error('❌ Load test failed:', error);
        }
    }

    /**
     * Run a batch of requests
     */
    async runBatch(count) {
        const endpoints = [
            '/health',
            '/api/health/detailed',
            '/api/cache/stats',
            '/api/ai/generate-ideas',
            '/api/assistant/calendar/upcoming'
        ];

        for (let i = 0; i < count; i++) {
            const endpoint = endpoints[i % endpoints.length];
            
            try {
                const result = await this.makeRequest(endpoint);
                this.results.push(result);
            } catch (error) {
                this.results.push({
                    endpoint,
                    responseTime: this.timeout,
                    status: 'error',
                    error: error.message
                });
            }
        }
    }

    /**
     * Make a single HTTP request
     */
    makeRequest(path) {
        return new Promise((resolve, reject) => {
            const startTime = performance.now();
            
            const options = {
                hostname: this.host,
                port: this.port,
                path: path,
                method: 'GET',
                headers: {
                    'User-Agent': 'HustleFinder-LoadTest/1.0'
                },
                timeout: this.timeout
            };

            const req = http.request(options, (res) => {
                let data = '';
                
                res.on('data', chunk => {
                    data += chunk;
                });

                res.on('end', () => {
                    const endTime = performance.now();
                    const responseTime = endTime - startTime;

                    resolve({
                        endpoint: path,
                        responseTime: Math.round(responseTime),
                        status: res.statusCode,
                        cached: res.headers['x-cache'] === 'HIT',
                        size: data.length
                    });
                });
            });

            req.on('error', (error) => {
                reject(error);
            });

            req.on('timeout', () => {
                req.destroy();
                reject(new Error('Request timeout'));
            });

            req.end();
        });
    }

    /**
     * Analyze and display results
     */
    analyzeResults(totalTime) {
        const successful = this.results.filter(r => r.status === 200 || (r.status >= 200 && r.status < 300));
        const errors = this.results.filter(r => r.status === 'error' || r.status >= 400);
        const cached = this.results.filter(r => r.cached);
        
        const responseTimes = successful.map(r => r.responseTime);
        const avgResponseTime = responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length;
        const minResponseTime = Math.min(...responseTimes);
        const maxResponseTime = Math.max(...responseTimes);
        
        // Calculate percentiles
        const sortedTimes = responseTimes.sort((a, b) => a - b);
        const p50 = sortedTimes[Math.floor(sortedTimes.length * 0.5)];
        const p95 = sortedTimes[Math.floor(sortedTimes.length * 0.95)];
        const p99 = sortedTimes[Math.floor(sortedTimes.length * 0.99)];

        const ultraFast = successful.filter(r => r.responseTime < 200).length;
        const ultraFastRate = (ultraFast / successful.length) * 100;

        const requestsPerSecond = (this.results.length / totalTime) * 1000;

        console.log('\n📊 PERFORMANCE RESULTS');
        console.log('═'.repeat(60));
        console.log(`⚡ Total Requests: ${this.results.length}`);
        console.log(`✅ Successful: ${successful.length} (${((successful.length / this.results.length) * 100).toFixed(1)}%)`);
        console.log(`❌ Errors: ${errors.length} (${((errors.length / this.results.length) * 100).toFixed(1)}%)`);
        console.log(`🎯 Ultra-Fast (<200ms): ${ultraFast} (${ultraFastRate.toFixed(1)}%)`);
        console.log(`📈 Cache Hits: ${cached.length} (${((cached.length / this.results.length) * 100).toFixed(1)}%)`);
        console.log();
        
        console.log('📏 RESPONSE TIME METRICS');
        console.log('─'.repeat(30));
        console.log(`Average: ${avgResponseTime.toFixed(1)}ms`);
        console.log(`Minimum: ${minResponseTime}ms`);
        console.log(`Maximum: ${maxResponseTime}ms`);
        console.log(`50th percentile: ${p50}ms`);
        console.log(`95th percentile: ${p95}ms`);
        console.log(`99th percentile: ${p99}ms`);
        console.log();

        console.log('🚀 THROUGHPUT METRICS');
        console.log('─'.repeat(30));
        console.log(`Requests/second: ${requestsPerSecond.toFixed(1)}`);
        console.log(`Total time: ${(totalTime / 1000).toFixed(2)}s`);
        console.log();

        // Performance assessment
        console.log('🎯 PERFORMANCE ASSESSMENT');
        console.log('─'.repeat(30));
        
        if (avgResponseTime < 200) {
            console.log('✅ TARGET ACHIEVED: Average response time < 200ms');
        } else {
            console.log('❌ TARGET MISSED: Average response time > 200ms');
        }

        if (ultraFastRate > 80) {
            console.log('✅ EXCELLENT: >80% ultra-fast responses');
        } else if (ultraFastRate > 60) {
            console.log('⚠️  GOOD: >60% ultra-fast responses');
        } else {
            console.log('❌ NEEDS IMPROVEMENT: <60% ultra-fast responses');
        }

        if (cached.length > 0) {
            console.log('✅ CACHING ACTIVE: Response caching working');
        } else {
            console.log('⚠️  CACHING: No cached responses detected');
        }

        console.log('\n🏆 ALEX ULTIMATE PERFORMANCE STATUS');
        console.log('═'.repeat(40));
        
        const performanceScore = this.calculatePerformanceScore(avgResponseTime, ultraFastRate, requestsPerSecond);
        console.log(`Performance Score: ${performanceScore}/100`);
        
        if (performanceScore >= 90) {
            console.log('🌟 STATUS: WORLD-CLASS PERFORMANCE! 🌟');
        } else if (performanceScore >= 75) {
            console.log('🚀 STATUS: EXCELLENT PERFORMANCE!');
        } else if (performanceScore >= 60) {
            console.log('📈 STATUS: GOOD PERFORMANCE');
        } else {
            console.log('⚠️  STATUS: NEEDS OPTIMIZATION');
        }
    }

    /**
     * Calculate overall performance score
     */
    calculatePerformanceScore(avgResponseTime, ultraFastRate, rps) {
        let score = 0;

        // Response time score (40 points max)
        if (avgResponseTime < 100) score += 40;
        else if (avgResponseTime < 200) score += 30;
        else if (avgResponseTime < 500) score += 20;
        else if (avgResponseTime < 1000) score += 10;

        // Ultra-fast rate score (30 points max)
        score += Math.min(30, (ultraFastRate / 100) * 30);

        // Throughput score (30 points max)
        if (rps > 100) score += 30;
        else if (rps > 50) score += 25;
        else if (rps > 20) score += 20;
        else if (rps > 10) score += 15;
        else if (rps > 5) score += 10;

        return Math.round(score);
    }
}

// Run load test if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
    const loadTester = new LoadTester({
        concurrent: parseInt(process.argv[2]) || 10,
        requests: parseInt(process.argv[3]) || 100,
        host: process.argv[4] || 'localhost',
        port: parseInt(process.argv[5]) || 8080
    });

    loadTester.run().then(() => {
        console.log('\n✅ Load test completed\n');
        process.exit(0);
    }).catch((error) => {
        console.error('❌ Load test failed:', error);
        process.exit(1);
    });
}

export default LoadTester;