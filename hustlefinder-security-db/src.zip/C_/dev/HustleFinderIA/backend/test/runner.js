#!/usr/bin/env node

// Simple test runner for ESM modules
import { readdirSync, statSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import './setup.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

// Simple test framework
global.describe = (description, testFunction) => {
  console.log(`\n📋 ${description}`);
  testFunction();
};

global.test = global.it = (description, testFunction) => {
  totalTests++;
  try {
    testFunction();
    console.log(`  ✅ ${description}`);
    passedTests++;
  } catch (error) {
    console.log(`  ❌ ${description}`);
    console.log(`     Error: ${error.message}`);
    failedTests++;
  }
};

global.beforeEach = (fn) => {
  // Simple beforeEach implementation
  if (typeof fn === 'function') {
    try {
      fn();
    } catch (error) {
      console.log(`⚠️ beforeEach failed: ${error.message}`);
    }
  }
};

global.before = global.beforeEach;
global.after = () => {}; // Placeholder
global.afterEach = () => {}; // Placeholder

global.expect = (actual) => ({
  toBe: (expected) => {
    if (actual !== expected) {
      throw new Error(`Expected ${expected}, got ${actual}`);
    }
  },
  toBeDefined: () => {
    if (actual === undefined) {
      throw new Error(`Expected value to be defined, got undefined`);
    }
  },
  toHaveProperty: (property) => {
    if (!actual || !actual.hasOwnProperty(property)) {
      throw new Error(`Expected object to have property ${property}`);
    }
  }
});

// Find and run test files
async function runTests() {
  console.log('🚀 Starting HustleFinder Tests\n');
  
  const testFiles = [];
  
  function findTestFiles(dir) {
    const files = readdirSync(dir);
    for (const file of files) {
      const filePath = join(dir, file);
      const stat = statSync(filePath);
      
      if (stat.isDirectory() && file !== 'node_modules') {
        findTestFiles(filePath);
      } else if (file.endsWith('.test.js')) {
        testFiles.push(filePath);
      }
    }
  }
  
  findTestFiles(__dirname);
  
  // Run each test file
  for (const testFile of testFiles) {
    console.log(`\n📁 Running ${testFile.replace(__dirname, '.')}`);
    try {
      // Convert Windows path to file:// URL
      const fileUrl = new URL(`file:///${testFile.replace(/\\/g, '/')}`).href;
      await import(fileUrl);
    } catch (error) {
      console.log(`❌ Failed to run ${testFile}: ${error.message}`);
      failedTests++;
    }
  }
  
  // Summary
  console.log('\n' + '='.repeat(50));
  console.log('📊 TEST SUMMARY');
  console.log('='.repeat(50));
  console.log(`Total Tests: ${totalTests}`);
  console.log(`✅ Passed: ${passedTests}`);
  console.log(`❌ Failed: ${failedTests}`);
  
  if (failedTests === 0) {
    console.log('\n🎉 All tests passed!');
    process.exit(0);
  } else {
    console.log('\n💥 Some tests failed!');
    process.exit(1);
  }
}

runTests().catch(error => {
  console.error('Test runner failed:', error);
  process.exit(1);
});